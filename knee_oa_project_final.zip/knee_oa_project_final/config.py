# =============================================================================
# config.py
# XCEPTION-BASED DEEP LEARNING FRAMEWORK FOR KNEE OSTEOARTHRITIS CLASSIFICATION
# WITH GRAD-CAM INTERPRETATION
# =============================================================================
# Central configuration for all pipeline stages.
# =============================================================================

import os

# ---------------------------------------------------------------------------
# PATHS
# ---------------------------------------------------------------------------
BASE_DIR        = os.path.dirname(os.path.abspath(__file__))
DATA_DIR        = os.path.join(BASE_DIR, "data_raw")          # raw dataset root
TRAIN_DIR       = os.path.join(DATA_DIR, "train")
VAL_DIR         = os.path.join(DATA_DIR, "val")
TEST_DIR        = os.path.join(DATA_DIR, "test")
CHECKPOINT_DIR  = os.path.join(BASE_DIR, "checkpoints")
REPORTS_DIR     = os.path.join(BASE_DIR, "reports")
LOG_DIR         = os.path.join(BASE_DIR, "logs")

for _d in [CHECKPOINT_DIR, REPORTS_DIR, LOG_DIR]:
    os.makedirs(_d, exist_ok=True)

# ---------------------------------------------------------------------------
# IMAGE SETTINGS (Stage 1)
# ---------------------------------------------------------------------------
IMAGE_SIZE      = (224, 224)          # Xception required input
IMAGE_CHANNELS  = 3
CLAHE_CLIP      = 2.0                 # CLAHE clip limit
CLAHE_GRID      = (8, 8)             # CLAHE tile grid size
PIXEL_NORM_MAX  = 255.0              # normalise pixel values to [0,1]

# ---------------------------------------------------------------------------
# AUGMENTATION SETTINGS (Stage 2)
# ---------------------------------------------------------------------------
AUG_ROTATION    = 15                  # degrees
AUG_HFLIP       = True
AUG_TRANSLATE   = 0.1                 # fraction of image size
AUG_SCALE       = (0.9, 1.1)

# ---------------------------------------------------------------------------
# MODEL SETTINGS (Stages 3-5)
# ---------------------------------------------------------------------------
BACKBONE        = "xception"
PRETRAINED      = True               # use ImageNet weights
DROPOUT_RATE    = 0.5
NUM_CLASSES     = 5                  # KL grades 0-4

# ---------------------------------------------------------------------------
# KL GRADE LABELS
# ---------------------------------------------------------------------------
CLASS_NAMES = {
    0: "Grade 0 – Normal",
    1: "Grade 1 – Doubtful OA",
    2: "Grade 2 – Mild OA",
    3: "Grade 3 – Moderate OA",
    4: "Grade 4 – Severe OA",
}
CLASS_LABELS = list(CLASS_NAMES.values())

# ---------------------------------------------------------------------------
# TRAINING SETTINGS (Stage 6)
# ---------------------------------------------------------------------------
BATCH_SIZE          = 32
EPOCHS              = 50
LEARNING_RATE       = 1e-4
OPTIMIZER           = "adam"
LOSS_FUNCTION       = "categorical_crossentropy"
EARLY_STOP_PATIENCE = 10             # epochs with no val improvement
LR_REDUCE_PATIENCE  = 5
LR_REDUCE_FACTOR    = 0.5
MIN_LR              = 1e-7

# ---------------------------------------------------------------------------
# GRAD-CAM SETTINGS (Stage 8)
# ---------------------------------------------------------------------------
GRADCAM_LAYER       = "block14_sepconv2_act"   # last conv layer in Xception
GRADCAM_ALPHA       = 0.4                      # heatmap overlay transparency

# ---------------------------------------------------------------------------
# REPORT SETTINGS (Stage 9)
# ---------------------------------------------------------------------------
REPORT_LOGO         = os.path.join(BASE_DIR, "assets", "logo.png")
REPORT_FONT         = "DejaVu Sans"
