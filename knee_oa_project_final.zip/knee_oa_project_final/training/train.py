# =============================================================================
# training/train.py
# Stage 6 – Model Training and Optimization
# =============================================================================
# Entry-point script to train the Xception knee OA classifier.
#
# Usage (Phase 1 – Feature Extraction):
#   python training/train.py --phase feature_extraction
#
# Usage (Phase 2 – Fine-tuning):
#   python training/train.py --phase fine_tuning --checkpoint checkpoints/xception_knee_oa_best.keras
#
# =============================================================================

import os
import sys
import argparse
import json
import time

import numpy as np
import tensorflow as tf

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import (
    TRAIN_DIR, VAL_DIR, BATCH_SIZE, EPOCHS,
    LEARNING_RATE, CHECKPOINT_DIR, LOG_DIR, CLASS_NAMES
)
from data import build_train_generator, build_val_generator, get_class_weights
from model import build_xception_model, get_callbacks, load_model


# =============================================================================
# TRAINING PHASES
# =============================================================================

def phase1_feature_extraction(args) -> tf.keras.Model:
    """
    Phase 1 – Feature Extraction (Frozen Backbone).

    The Xception backbone is frozen. Only the classification head is trained.
    This leverages pretrained ImageNet features for knee OA classification.

    Parameters
    ----------
    args : argparse.Namespace

    Returns
    -------
    tf.keras.Model
        Trained model after Phase 1.
    """
    print("\n" + "=" * 60)
    print("  PHASE 1: FEATURE EXTRACTION (Frozen Backbone)")
    print("=" * 60)

    # ── Data generators
    print("\n[INFO] Building data generators...")
    train_gen = build_train_generator(TRAIN_DIR, BATCH_SIZE)
    val_gen   = build_val_generator(VAL_DIR, BATCH_SIZE)

    print(f"[INFO] Training samples  : {train_gen.samples}")
    print(f"[INFO] Validation samples: {val_gen.samples}")
    print(f"[INFO] Class mapping     : {train_gen.class_indices}")

    # ── Class weights for imbalance
    class_weights = get_class_weights(train_gen)
    print(f"[INFO] Class weights     : {class_weights}")

    # ── Build model
    print("\n[INFO] Building Xception model...")
    model = build_xception_model(
        learning_rate=LEARNING_RATE,
        fine_tune_from=None          # Backbone frozen
    )
    model.summary()

    # ── Callbacks
    callbacks = get_callbacks(model_name="xception_knee_oa_phase1")

    # ── Train
    print("\n[INFO] Starting Phase 1 training...")
    start = time.time()

    history = model.fit(
        train_gen,
        epochs=EPOCHS,
        validation_data=val_gen,
        callbacks=callbacks,
        class_weight=class_weights,
        verbose=1
    )

    elapsed = time.time() - start
    print(f"\n[INFO] Phase 1 training complete in {elapsed/60:.1f} min")

    # ── Save history
    _save_history(history.history, "phase1_history.json")

    return model, history


def phase2_fine_tuning(args, model: tf.keras.Model = None) -> tf.keras.Model:
    """
    Phase 2 – Fine-Tuning (Partial Backbone Unfreeze).

    Unfreeze the top layers of Xception for end-to-end fine-tuning
    with a lower learning rate.

    Parameters
    ----------
    args : argparse.Namespace
    model : tf.keras.Model, optional
        Pre-trained model from Phase 1. If None, loads from checkpoint.

    Returns
    -------
    tf.keras.Model
        Fine-tuned model.
    """
    print("\n" + "=" * 60)
    print("  PHASE 2: FINE-TUNING (Partial Backbone Unfreeze)")
    print("=" * 60)

    # ── Load model if not passed
    if model is None:
        checkpoint = args.checkpoint or os.path.join(
            CHECKPOINT_DIR, "xception_knee_oa_phase1_best.keras"
        )
        print(f"\n[INFO] Loading checkpoint: {checkpoint}")
        model = load_model(checkpoint)

    # ── Unfreeze from block 12 onward (last 2 blocks of Xception)
    FINE_TUNE_FROM = 116   # ~last 20 layers of Xception
    backbone = model.get_layer("xception")
    backbone.trainable = True
    for layer in backbone.layers[:FINE_TUNE_FROM]:
        layer.trainable = False

    trainable_count = sum(1 for l in model.layers if l.trainable)
    print(f"[INFO] Trainable layers  : {trainable_count}")

    # ── Recompile with lower LR
    fine_tune_lr = LEARNING_RATE * 0.1
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=fine_tune_lr),
        loss="categorical_crossentropy",
        metrics=["accuracy",
                 tf.keras.metrics.AUC(name="auc"),
                 tf.keras.metrics.Precision(name="precision"),
                 tf.keras.metrics.Recall(name="recall")]
    )

    # ── Data generators
    train_gen = build_train_generator(TRAIN_DIR, BATCH_SIZE)
    val_gen   = build_val_generator(VAL_DIR, BATCH_SIZE)
    class_weights = get_class_weights(train_gen)

    # ── Callbacks
    callbacks = get_callbacks(model_name="xception_knee_oa_phase2")

    # ── Fine-tune
    print("\n[INFO] Starting Phase 2 fine-tuning...")
    start = time.time()

    history = model.fit(
        train_gen,
        epochs=EPOCHS // 2,
        validation_data=val_gen,
        callbacks=callbacks,
        class_weight=class_weights,
        verbose=1
    )

    elapsed = time.time() - start
    print(f"\n[INFO] Phase 2 fine-tuning complete in {elapsed/60:.1f} min")

    _save_history(history.history, "phase2_history.json")

    return model, history


# =============================================================================
# HELPERS
# =============================================================================

def _save_history(history: dict, filename: str) -> None:
    """Persist training history as JSON."""
    path = os.path.join(LOG_DIR, filename)
    # Convert numpy values to native Python floats
    serializable = {
        k: [float(v) for v in vals]
        for k, vals in history.items()
    }
    with open(path, "w") as f:
        json.dump(serializable, f, indent=2)
    print(f"[INFO] Training history saved: {path}")


def set_seeds(seed: int = 42) -> None:
    """Set random seeds for reproducibility."""
    import random
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)


# =============================================================================
# CLI ENTRY POINT
# =============================================================================

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train Xception Knee OA Classifier"
    )
    parser.add_argument(
        "--phase",
        choices=["feature_extraction", "fine_tuning", "both"],
        default="both",
        help="Training phase to run (default: both)"
    )
    parser.add_argument(
        "--checkpoint",
        type=str,
        default=None,
        help="Path to model checkpoint for fine-tuning phase"
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility"
    )
    return parser.parse_args()


def main():
    args = parse_args()
    set_seeds(args.seed)

    # GPU memory growth
    gpus = tf.config.list_physical_devices("GPU")
    if gpus:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        print(f"[INFO] GPUs available: {len(gpus)}")
    else:
        print("[WARN] No GPU detected. Training on CPU (will be slow).")

    print(f"\n[INFO] TensorFlow version : {tf.__version__}")
    print(f"[INFO] Random seed        : {args.seed}")
    print(f"[INFO] Training phase     : {args.phase}")

    model = None
    history = None

    if args.phase in ("feature_extraction", "both"):
        model, history = phase1_feature_extraction(args)

    if args.phase in ("fine_tuning", "both"):
        model, history = phase2_fine_tuning(args, model)

    print("\n[INFO] Training pipeline complete.")


if __name__ == "__main__":
    main()
