# =============================================================================
# training/evaluate.py
# Stage 7 – Model Evaluation
# =============================================================================
# Comprehensive evaluation of the trained Xception model on the test set.
#
# Usage:
#   python training/evaluate.py --checkpoint checkpoints/xception_knee_oa_phase2_best.keras
#
# =============================================================================

import os
import sys
import argparse
import json

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns

from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    precision_recall_curve,
    average_precision_score,
    roc_auc_score,
    roc_curve
)

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import (
    TEST_DIR, BATCH_SIZE, CLASS_NAMES, CLASS_LABELS,
    NUM_CLASSES, REPORTS_DIR, LOG_DIR
)
from data import build_val_generator
from model import load_model


# =============================================================================
# EVALUATION RUNNER
# =============================================================================

def evaluate_model(model_path: str,
                    test_dir: str = TEST_DIR,
                    batch_size: int = BATCH_SIZE,
                    save_plots: bool = True) -> dict:
    """
    Full evaluation pipeline on the test set.

    Computes:
    - Accuracy, Precision, Recall, F1-Score per class
    - Confusion Matrix
    - Per-class Precision-Recall curves
    - Per-class ROC-AUC curves

    Parameters
    ----------
    model_path : str
        Path to .keras checkpoint.
    test_dir : str
        Directory with class sub-folders for test images.
    batch_size : int
    save_plots : bool
        Whether to save evaluation figures to disk.

    Returns
    -------
    dict
        Dictionary containing all computed metrics.
    """
    print("\n" + "=" * 60)
    print("  MODEL EVALUATION")
    print("=" * 60)

    # ── Load model
    model = load_model(model_path)

    # ── Test generator (no augmentation)
    test_gen = build_val_generator(test_dir, batch_size)
    print(f"\n[INFO] Test samples: {test_gen.samples}")

    # ── Predict
    print("[INFO] Running inference on test set...")
    y_prob = model.predict(test_gen, verbose=1)
    y_pred = np.argmax(y_prob, axis=1)
    y_true = test_gen.classes

    # ── Classification report
    report = classification_report(
        y_true, y_pred,
        target_names=CLASS_LABELS,
        output_dict=True
    )
    print("\n[RESULT] Classification Report:")
    print(classification_report(y_true, y_pred, target_names=CLASS_LABELS))

    # ── Confusion matrix
    cm = confusion_matrix(y_true, y_pred)

    # ── ROC-AUC (one-vs-rest)
    from tensorflow.keras.utils import to_categorical
    y_true_ohe = to_categorical(y_true, num_classes=NUM_CLASSES)
    try:
        roc_auc = roc_auc_score(y_true_ohe, y_prob,
                                  multi_class="ovr", average="macro")
    except Exception:
        roc_auc = None
    print(f"[RESULT] Macro ROC-AUC: {roc_auc:.4f}" if roc_auc else
          "[WARN] Could not compute ROC-AUC (possibly missing classes).")

    metrics = {
        "accuracy"         : float(report["accuracy"]),
        "macro_precision"  : float(report["macro avg"]["precision"]),
        "macro_recall"     : float(report["macro avg"]["recall"]),
        "macro_f1"         : float(report["macro avg"]["f1-score"]),
        "macro_roc_auc"    : float(roc_auc) if roc_auc is not None else None,
        "per_class"        : {
            CLASS_LABELS[i]: {
                "precision": float(report[CLASS_LABELS[i]]["precision"]),
                "recall"   : float(report[CLASS_LABELS[i]]["recall"]),
                "f1"       : float(report[CLASS_LABELS[i]]["f1-score"]),
                "support"  : int(report[CLASS_LABELS[i]]["support"]),
            }
            for i in range(NUM_CLASSES)
        },
        "confusion_matrix" : cm.tolist()
    }

    # ── Save metrics JSON
    metrics_path = os.path.join(REPORTS_DIR, "evaluation_metrics.json")
    with open(metrics_path, "w") as f:
        json.dump(metrics, f, indent=2)
    print(f"\n[INFO] Metrics saved: {metrics_path}")

    # ── Plots
    if save_plots:
        _plot_confusion_matrix(cm)
        _plot_precision_recall_curves(y_true_ohe, y_prob)
        _plot_roc_curves(y_true_ohe, y_prob)
        _plot_training_history()

    return metrics


# =============================================================================
# PLOTTING HELPERS
# =============================================================================

DARK_BG  = "#0e1117"
PLOT_FG  = "#ffffff"
ACCENT   = "#00d4ff"

_plot_style = {
    "figure.facecolor"   : DARK_BG,
    "axes.facecolor"     : "#1a1d2e",
    "axes.edgecolor"     : "#444",
    "axes.labelcolor"    : PLOT_FG,
    "xtick.color"        : PLOT_FG,
    "ytick.color"        : PLOT_FG,
    "text.color"         : PLOT_FG,
    "grid.color"         : "#2a2d3e",
    "grid.linestyle"     : "--",
    "grid.alpha"         : 0.5,
}


def _plot_confusion_matrix(cm: np.ndarray) -> None:
    """Plot and save the normalized confusion matrix."""
    plt.rcParams.update(_plot_style)

    cm_norm = cm.astype(float) / (cm.sum(axis=1, keepdims=True) + 1e-8)

    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    fig.suptitle("Confusion Matrix", color=PLOT_FG, fontsize=14,
                  fontweight="bold")

    for ax, data, title, fmt in zip(
        axes,
        [cm, cm_norm],
        ["Raw Counts", "Normalized"],
        ["d", ".2f"]
    ):
        sns.heatmap(
            data, annot=True, fmt=fmt, cmap="Blues",
            xticklabels=CLASS_LABELS, yticklabels=CLASS_LABELS,
            ax=ax, linewidths=0.5, linecolor="#333",
            cbar_kws={"shrink": 0.8}
        )
        ax.set_title(title, color=PLOT_FG)
        ax.set_xlabel("Predicted", color=PLOT_FG)
        ax.set_ylabel("Actual", color=PLOT_FG)
        ax.tick_params(colors=PLOT_FG, rotation=30)

    plt.tight_layout()
    path = os.path.join(REPORTS_DIR, "confusion_matrix.png")
    fig.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK_BG)
    plt.close(fig)
    print(f"[INFO] Confusion matrix saved: {path}")


def _plot_precision_recall_curves(y_true_ohe: np.ndarray,
                                    y_prob: np.ndarray) -> None:
    """Plot per-class Precision-Recall curves."""
    plt.rcParams.update(_plot_style)

    COLORS = ["#e74c3c", "#3498db", "#2ecc71", "#f39c12", "#9b59b6"]

    fig, ax = plt.subplots(figsize=(10, 7))
    fig.suptitle("Precision-Recall Curves", color=PLOT_FG, fontsize=14,
                  fontweight="bold")

    for i in range(NUM_CLASSES):
        precision, recall, _ = precision_recall_curve(
            y_true_ohe[:, i], y_prob[:, i]
        )
        ap = average_precision_score(y_true_ohe[:, i], y_prob[:, i])
        ax.plot(recall, precision,
                label=f"KL {i} (AP={ap:.2f})",
                color=COLORS[i], linewidth=2)

    ax.set_xlabel("Recall")
    ax.set_ylabel("Precision")
    ax.legend(loc="lower left", framealpha=0.3)
    ax.grid(True)

    path = os.path.join(REPORTS_DIR, "precision_recall_curves.png")
    fig.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK_BG)
    plt.close(fig)
    print(f"[INFO] PR curves saved: {path}")


def _plot_roc_curves(y_true_ohe: np.ndarray,
                      y_prob: np.ndarray) -> None:
    """Plot per-class ROC curves."""
    plt.rcParams.update(_plot_style)

    COLORS = ["#e74c3c", "#3498db", "#2ecc71", "#f39c12", "#9b59b6"]

    fig, ax = plt.subplots(figsize=(10, 7))
    fig.suptitle("ROC Curves (One-vs-Rest)", color=PLOT_FG, fontsize=14,
                  fontweight="bold")

    for i in range(NUM_CLASSES):
        try:
            fpr, tpr, _ = roc_curve(y_true_ohe[:, i], y_prob[:, i])
            auc = roc_auc_score(y_true_ohe[:, i], y_prob[:, i])
            ax.plot(fpr, tpr,
                    label=f"KL {i} (AUC={auc:.2f})",
                    color=COLORS[i], linewidth=2)
        except Exception:
            pass

    ax.plot([0, 1], [0, 1], "w--", linewidth=1, label="Chance")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.legend(loc="lower right", framealpha=0.3)
    ax.grid(True)

    path = os.path.join(REPORTS_DIR, "roc_curves.png")
    fig.savefig(path, dpi=150, bbox_inches="tight", facecolor=DARK_BG)
    plt.close(fig)
    print(f"[INFO] ROC curves saved: {path}")


def _plot_training_history() -> None:
    """Plot training and validation accuracy/loss curves from saved history."""
    plt.rcParams.update(_plot_style)

    for phase, filename in [("Phase 1", "phase1_history.json"),
                              ("Phase 2", "phase2_history.json")]:
        path = os.path.join(LOG_DIR, filename)
        if not os.path.exists(path):
            continue

        with open(path) as f:
            hist = json.load(f)

        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        fig.suptitle(f"Training History – {phase}", color=PLOT_FG,
                      fontsize=14, fontweight="bold")

        epochs = range(1, len(hist["accuracy"]) + 1)

        # Accuracy
        axes[0].plot(epochs, hist["accuracy"],    color=ACCENT,  label="Train Acc")
        axes[0].plot(epochs, hist["val_accuracy"], color="#ff6b6b", label="Val Acc",
                     linestyle="--")
        axes[0].set_title("Accuracy",  color=PLOT_FG)
        axes[0].set_xlabel("Epoch");   axes[0].set_ylabel("Accuracy")
        axes[0].legend(framealpha=0.3); axes[0].grid(True)

        # Loss
        axes[1].plot(epochs, hist["loss"],     color=ACCENT,  label="Train Loss")
        axes[1].plot(epochs, hist["val_loss"],  color="#ff6b6b", label="Val Loss",
                     linestyle="--")
        axes[1].set_title("Loss",  color=PLOT_FG)
        axes[1].set_xlabel("Epoch"); axes[1].set_ylabel("Loss")
        axes[1].legend(framealpha=0.3); axes[1].grid(True)

        plt.tight_layout()
        out_path = os.path.join(
            REPORTS_DIR,
            f"training_history_{phase.replace(' ', '_').lower()}.png"
        )
        fig.savefig(out_path, dpi=150, bbox_inches="tight", facecolor=DARK_BG)
        plt.close(fig)
        print(f"[INFO] History plot saved: {out_path}")


# =============================================================================
# CLI
# =============================================================================

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Evaluate Xception Knee OA Classifier"
    )
    parser.add_argument(
        "--checkpoint",
        type=str,
        required=True,
        help="Path to trained model checkpoint (.keras or .h5)"
    )
    parser.add_argument(
        "--test_dir",
        type=str,
        default=TEST_DIR,
        help="Path to test dataset directory"
    )
    parser.add_argument(
        "--no_plots",
        action="store_true",
        help="Skip saving evaluation plots"
    )
    return parser.parse_args()


def main():
    args = parse_args()
    evaluate_model(
        model_path=args.checkpoint,
        test_dir=args.test_dir,
        save_plots=not args.no_plots
    )


if __name__ == "__main__":
    main()
