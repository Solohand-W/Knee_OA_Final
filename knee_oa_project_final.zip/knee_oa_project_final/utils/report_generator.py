# =============================================================================
# utils/report_generator.py
# PDF Report Generation for Knee OA Diagnostic Results
# =============================================================================

import os
import io
import sys
from datetime import datetime
from typing import Dict, Any, Optional
import numpy as np

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import REPORTS_DIR, CLASS_NAMES
from utils.helpers import get_clinical_description, generate_report_metadata


def generate_pdf_report(
    original_image: np.ndarray,
    gradcam_overlay: np.ndarray,
    prediction: Dict[str, Any],
    output_path: Optional[str] = None
) -> bytes:
    """
    Generate a professional PDF diagnostic report.

    The report contains:
    - System header and report ID
    - Uploaded X-ray image
    - Grad-CAM overlay visualization
    - Predicted KL grade and confidence score
    - Class probability breakdown
    - Clinical description
    - Disclaimer

    Parameters
    ----------
    original_image : np.ndarray
        Original preprocessed X-ray (224, 224, 3), float32.
    gradcam_overlay : np.ndarray
        Grad-CAM overlaid image (224, 224, 3), uint8.
    prediction : dict
        Output of format_prediction().
    output_path : str, optional
        If provided, save PDF to this path.

    Returns
    -------
    bytes
        Raw PDF bytes.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import cm, mm
        from reportlab.platypus import (
            SimpleDocTemplate, Paragraph, Spacer, Table,
            TableStyle, Image as RLImage, HRFlowable
        )
        from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
        from PIL import Image as PILImage
    except ImportError:
        raise ImportError(
            "reportlab and Pillow are required for PDF generation.\n"
            "Install: pip install reportlab Pillow"
        )

    metadata = generate_report_metadata(prediction)
    buffer = io.BytesIO()

    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=2 * cm,
        leftMargin=2 * cm,
        topMargin=2 * cm,
        bottomMargin=2 * cm
    )

    # ── Styles
    styles = getSampleStyleSheet()
    style_title = ParagraphStyle(
        "Title",
        parent=styles["Title"],
        fontSize=16,
        textColor=colors.HexColor("#1a3c5e"),
        spaceAfter=6,
        alignment=TA_CENTER,
        fontName="Helvetica-Bold"
    )
    style_subtitle = ParagraphStyle(
        "Subtitle",
        parent=styles["Normal"],
        fontSize=10,
        textColor=colors.HexColor("#555"),
        spaceAfter=4,
        alignment=TA_CENTER
    )
    style_section = ParagraphStyle(
        "Section",
        parent=styles["Heading2"],
        fontSize=12,
        textColor=colors.HexColor("#1a3c5e"),
        spaceBefore=12,
        spaceAfter=6,
        fontName="Helvetica-Bold"
    )
    style_body = ParagraphStyle(
        "Body",
        parent=styles["Normal"],
        fontSize=10,
        textColor=colors.black,
        spaceAfter=4,
        alignment=TA_JUSTIFY,
        leading=14
    )
    style_disclaimer = ParagraphStyle(
        "Disclaimer",
        parent=styles["Normal"],
        fontSize=8,
        textColor=colors.HexColor("#888"),
        spaceAfter=4,
        alignment=TA_JUSTIFY,
        fontName="Helvetica-Oblique"
    )

    severity_colors_hex = {
        "Normal"  : "#27ae60",
        "Mild"    : "#f39c12",
        "Moderate": "#e67e22",
        "Severe"  : "#c0392b"
    }

    # ── Build story
    story = []

    # Header
    story.append(Paragraph(
        "KNEE OSTEOARTHRITIS DIAGNOSTIC REPORT", style_title
    ))
    story.append(Paragraph(
        "Xception-Based Deep Learning Framework with Grad-CAM Interpretation",
        style_subtitle
    ))
    story.append(HRFlowable(width="100%", thickness=2,
                              color=colors.HexColor("#1a3c5e")))
    story.append(Spacer(1, 0.4 * cm))

    # Report metadata table
    meta_data = [
        ["Report ID",  metadata["report_id"],
         "Date & Time", metadata["timestamp"]],
        ["System",     metadata["system"],
         "Version",    metadata["version"]],
    ]
    meta_table = Table(meta_data, colWidths=[3.5 * cm, 6 * cm, 3 * cm, 5 * cm])
    meta_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f0f4f8")),
        ("TEXTCOLOR",  (0, 0), (-1, -1), colors.HexColor("#333")),
        ("FONTNAME",   (0, 0), (0, -1),  "Helvetica-Bold"),
        ("FONTNAME",   (2, 0), (2, -1),  "Helvetica-Bold"),
        ("FONTSIZE",   (0, 0), (-1, -1), 9),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1),
         [colors.HexColor("#f0f4f8"), colors.HexColor("#e8eef5")]),
        ("BOX",        (0, 0), (-1, -1), 0.5, colors.HexColor("#ccc")),
        ("INNERGRID",  (0, 0), (-1, -1), 0.25, colors.HexColor("#ccc")),
        ("PADDING",    (0, 0), (-1, -1), 4),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 0.5 * cm))

    # ── Prediction Result
    story.append(Paragraph("DIAGNOSTIC RESULT", style_section))

    grade_color = colors.HexColor(
        severity_colors_hex.get(prediction["severity"], "#333")
    )
    result_data = [
        ["KL Grade",   f"Grade {prediction['kl_grade']}",
         "Diagnosis",  prediction["grade_name"]],
        ["Severity",   prediction["severity"],
         "Confidence", prediction["confidence_pct"]],
    ]
    result_table = Table(result_data, colWidths=[3 * cm, 5 * cm, 3 * cm, 6.5 * cm])
    result_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#fff9f0")),
        ("FONTNAME",   (0, 0), (0, -1),  "Helvetica-Bold"),
        ("FONTNAME",   (2, 0), (2, -1),  "Helvetica-Bold"),
        ("FONTSIZE",   (0, 0), (-1, -1), 10),
        ("FONTNAME",   (1, 0), (1, 0),   "Helvetica-Bold"),
        ("TEXTCOLOR",  (1, 0), (1, 0),   grade_color),
        ("BOX",        (0, 0), (-1, -1), 1,   grade_color),
        ("INNERGRID",  (0, 0), (-1, -1), 0.5, colors.HexColor("#ddd")),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1),
         [colors.HexColor("#fff9f0"), colors.HexColor("#fff3e0")]),
        ("PADDING",    (0, 0), (-1, -1), 6),
        ("ALIGN",      (0, 0), (-1, -1), "LEFT"),
    ]))
    story.append(result_table)
    story.append(Spacer(1, 0.4 * cm))

    # Probability table
    story.append(Paragraph("Class Probability Breakdown", style_section))
    prob_rows = [["KL Grade", "Diagnosis", "Probability"]]
    for i in range(5):
        p = prediction["probabilities"].get(CLASS_NAMES[i], 0.0)
        marker = " ◀ PREDICTED" if i == prediction["kl_grade"] else ""
        prob_rows.append([
            f"Grade {i}",
            CLASS_NAMES[i] + marker,
            f"{p:.2%}"
        ])
    prob_table = Table(prob_rows, colWidths=[3 * cm, 11 * cm, 3.5 * cm])
    prob_table.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, 0),  colors.HexColor("#1a3c5e")),
        ("TEXTCOLOR",     (0, 0), (-1, 0),  colors.white),
        ("FONTNAME",      (0, 0), (-1, 0),  "Helvetica-Bold"),
        ("FONTSIZE",      (0, 0), (-1, -1), 9),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1),
         [colors.HexColor("#f7f9fc"), colors.white]),
        ("BOX",           (0, 0), (-1, -1), 0.5, colors.HexColor("#ccc")),
        ("INNERGRID",     (0, 0), (-1, -1), 0.25, colors.HexColor("#ddd")),
        ("PADDING",       (0, 0), (-1, -1), 5),
        ("BACKGROUND",    (0, prediction["kl_grade"] + 1),
         (-1, prediction["kl_grade"] + 1), colors.HexColor("#fff3cd")),
    ]))
    story.append(prob_table)
    story.append(Spacer(1, 0.4 * cm))

    # ── Images
    story.append(Paragraph("RADIOGRAPHIC IMAGES", style_section))

    def _np_to_rl_image(arr: np.ndarray, width_cm: float) -> RLImage:
        """Convert numpy array to ReportLab Image."""
        if arr.max() <= 1.0:
            arr = (arr * 255).astype(np.uint8)
        pil_img = PILImage.fromarray(arr.astype(np.uint8))
        buf = io.BytesIO()
        pil_img.save(buf, format="PNG")
        buf.seek(0)
        w = width_cm * cm
        aspect = pil_img.height / pil_img.width
        return RLImage(buf, width=w, height=w * aspect)

    img_xray  = _np_to_rl_image(original_image,  7.5)
    img_gcam  = _np_to_rl_image(gradcam_overlay, 7.5)

    image_table = Table(
        [[img_xray, img_gcam]],
        colWidths=[8.5 * cm, 8.5 * cm]
    )
    image_table.setStyle(TableStyle([
        ("ALIGN",   (0, 0), (-1, -1), "CENTER"),
        ("VALIGN",  (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story.append(image_table)

    caption_table = Table(
        [["Original X-ray", "Grad-CAM Heatmap Overlay"]],
        colWidths=[8.5 * cm, 8.5 * cm]
    )
    caption_table.setStyle(TableStyle([
        ("ALIGN",    (0, 0), (-1, -1), "CENTER"),
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica-Oblique"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("TEXTCOLOR", (0, 0), (-1, -1), colors.HexColor("#666")),
    ]))
    story.append(caption_table)
    story.append(Spacer(1, 0.4 * cm))

    # ── Clinical Description
    story.append(Paragraph("CLINICAL INTERPRETATION", style_section))
    clinical_desc = get_clinical_description(prediction["kl_grade"])
    story.append(Paragraph(clinical_desc, style_body))
    story.append(Spacer(1, 0.4 * cm))

    # ── Disclaimer
    story.append(HRFlowable(width="100%", thickness=1,
                              color=colors.HexColor("#ccc")))
    story.append(Spacer(1, 0.2 * cm))
    story.append(Paragraph("⚠ DISCLAIMER", ParagraphStyle(
        "DisclaimerHeader",
        parent=styles["Normal"],
        fontSize=9,
        fontName="Helvetica-Bold",
        textColor=colors.HexColor("#c0392b")
    )))
    story.append(Paragraph(metadata["disclaimer"], style_disclaimer))

    # Build PDF
    doc.build(story)
    pdf_bytes = buffer.getvalue()

    if output_path:
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "wb") as f:
            f.write(pdf_bytes)
        print(f"[INFO] PDF report saved: {output_path}")

    return pdf_bytes
