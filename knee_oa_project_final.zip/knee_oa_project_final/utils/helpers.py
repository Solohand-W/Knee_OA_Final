# =============================================================================
# utils/helpers.py
# Shared utility functions used across the pipeline
# =============================================================================

import os
import io
import base64
import json
from datetime import datetime
from typing import Dict, Any, Optional

import numpy as np
import cv2
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import CLASS_NAMES, REPORTS_DIR


# =============================================================================
# IMAGE UTILITIES
# =============================================================================

def numpy_to_pil(image: np.ndarray) -> Image.Image:
    """Convert numpy array to PIL Image."""
    if image.max() <= 1.0:
        image = (image * 255).astype(np.uint8)
    if image.ndim == 2:
        return Image.fromarray(image, mode="L")
    return Image.fromarray(image.astype(np.uint8), mode="RGB")


def pil_to_numpy(image: Image.Image) -> np.ndarray:
    """Convert PIL Image to numpy float32 array in [0, 1]."""
    arr = np.array(image).astype(np.float32) / 255.0
    return arr


def encode_image_base64(image: np.ndarray) -> str:
    """
    Encode a numpy image as a base64 PNG string for HTML embedding.

    Parameters
    ----------
    image : np.ndarray
        Image array (H, W, 3) or (H, W), values in [0, 1] or [0, 255].

    Returns
    -------
    str
        Base64-encoded PNG string.
    """
    pil_img = numpy_to_pil(image)
    buffer = io.BytesIO()
    pil_img.save(buffer, format="PNG")
    return base64.b64encode(buffer.getvalue()).decode("utf-8")


def fig_to_numpy(fig: plt.Figure) -> np.ndarray:
    """Convert matplotlib figure to numpy array."""
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=100, bbox_inches="tight")
    buf.seek(0)
    img = Image.open(buf)
    return np.array(img)


def fig_to_bytes(fig: plt.Figure) -> bytes:
    """Convert matplotlib figure to PNG bytes."""
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    buf.seek(0)
    return buf.getvalue()


# =============================================================================
# PREDICTION UTILITIES
# =============================================================================

def format_prediction(predicted_class: int,
                        probabilities: np.ndarray) -> Dict[str, Any]:
    """
    Format model prediction output for display.

    Parameters
    ----------
    predicted_class : int
        KL grade index (0-4).
    probabilities : np.ndarray
        Softmax probabilities for each class.

    Returns
    -------
    dict
        Formatted prediction dictionary.
    """
    confidence = float(probabilities[predicted_class])
    grade_name = CLASS_NAMES.get(predicted_class, f"Grade {predicted_class}")

    severity_map = {0: "Normal", 1: "Mild", 2: "Mild", 3: "Moderate", 4: "Severe"}
    severity_color = {
        "Normal": "#2ecc71",
        "Mild"  : "#f39c12",
        "Moderate": "#e67e22",
        "Severe": "#e74c3c"
    }

    severity = severity_map[predicted_class]

    return {
        "kl_grade"      : predicted_class,
        "grade_name"    : grade_name,
        "confidence"    : confidence,
        "confidence_pct": f"{confidence:.1%}",
        "severity"      : severity,
        "severity_color": severity_color[severity],
        "probabilities" : {
            CLASS_NAMES[i]: float(probabilities[i])
            for i in range(len(probabilities))
        }
    }


def get_clinical_description(kl_grade: int) -> str:
    """
    Return a clinical description for the predicted KL grade.

    Parameters
    ----------
    kl_grade : int
        Kellgren-Lawrence grade (0-4).

    Returns
    -------
    str
        Clinical interpretation text.
    """
    descriptions = {
        0: (
            "No radiographic features of osteoarthritis are present. "
            "Joint space width is normal. No osteophytes detected. "
            "The knee appears structurally healthy."
        ),
        1: (
            "Doubtful joint space narrowing with possible osteophytic lipping. "
            "Radiographic findings are equivocal. "
            "Clinical correlation and follow-up recommended."
        ),
        2: (
            "Definite osteophytes with possible joint space narrowing on anteroposterior "
            "weight-bearing radiograph. Early OA changes are present. "
            "Conservative management may be appropriate."
        ),
        3: (
            "Multiple osteophytes, definite narrowing of joint space, some sclerosis, "
            "and possible deformity of bone ends. Moderate OA. "
            "Pain management and physiotherapy are typically indicated."
        ),
        4: (
            "Large osteophytes, marked narrowing of joint space, severe sclerosis, "
            "and definite deformity of bone ends. Severe OA. "
            "Surgical intervention (e.g., total knee arthroplasty) may be considered."
        )
    }
    return descriptions.get(kl_grade, "No description available.")


# =============================================================================
# REPORT UTILITIES
# =============================================================================

def generate_report_metadata(prediction: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate metadata dictionary for PDF report generation.

    Parameters
    ----------
    prediction : dict
        Output of format_prediction().

    Returns
    -------
    dict
        Report metadata.
    """
    return {
        "report_id"     : _generate_report_id(),
        "timestamp"     : datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "system"        : "Xception-Based Knee OA Classification System",
        "version"       : "1.0.0",
        "kl_grade"      : prediction["kl_grade"],
        "grade_name"    : prediction["grade_name"],
        "confidence"    : prediction["confidence_pct"],
        "severity"      : prediction["severity"],
        "description"   : get_clinical_description(prediction["kl_grade"]),
        "disclaimer"    : (
            "This report is generated by an AI-assisted diagnostic tool "
            "and is intended for research and educational purposes only. "
            "It does not constitute a medical diagnosis. "
            "All findings must be reviewed and confirmed by a qualified clinician."
        )
    }


def _generate_report_id() -> str:
    """Generate a unique report ID."""
    import uuid
    return f"KOA-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"


def save_json(data: dict, filename: str) -> str:
    """Save dictionary to JSON file in REPORTS_DIR."""
    path = os.path.join(REPORTS_DIR, filename)
    with open(path, "w") as f:
        json.dump(data, f, indent=2, default=str)
    return path


# =============================================================================
# DATASET UTILITIES
# =============================================================================

def count_images_per_class(dataset_dir: str) -> Dict[str, int]:
    """
    Count images per class in a directory-structured dataset.

    Parameters
    ----------
    dataset_dir : str
        Root directory with class sub-folders.

    Returns
    -------
    dict
        {class_name: count}
    """
    counts = {}
    if not os.path.isdir(dataset_dir):
        return counts
    for cls in sorted(os.listdir(dataset_dir)):
        cls_path = os.path.join(dataset_dir, cls)
        if os.path.isdir(cls_path):
            n = sum(
                1 for f in os.listdir(cls_path)
                if f.lower().endswith((".png", ".jpg", ".jpeg", ".dcm"))
            )
            counts[cls] = n
    return counts


def plot_class_distribution(counts: Dict[str, int],
                              title: str = "Dataset Class Distribution"
                              ) -> plt.Figure:
    """
    Plot bar chart of class distribution.

    Parameters
    ----------
    counts : dict
        {class_name: count}
    title : str

    Returns
    -------
    plt.Figure
    """
    DARK_BG = "#0e1117"
    fig, ax = plt.subplots(figsize=(9, 5), facecolor=DARK_BG)
    ax.set_facecolor("#1a1d2e")

    labels = list(counts.keys())
    values = list(counts.values())
    colors = ["#3498db", "#2ecc71", "#f39c12", "#e67e22", "#e74c3c"]

    bars = ax.bar(labels, values,
                   color=colors[:len(labels)],
                   edgecolor="white", linewidth=0.5)
    ax.set_title(title, color="white", fontsize=13, fontweight="bold")
    ax.set_xlabel("KL Grade", color="white")
    ax.set_ylabel("Number of Images", color="white")
    ax.tick_params(colors="white")
    for spine in ax.spines.values():
        spine.set_edgecolor("#444")

    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 5,
                str(val), ha="center", color="white", fontsize=10)

    plt.tight_layout()
    return fig
