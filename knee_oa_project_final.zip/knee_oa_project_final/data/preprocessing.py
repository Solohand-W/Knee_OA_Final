# =============================================================================
# data/preprocessing.py
# Stage 1 – Clinical Data Acquisition & Preprocessing
# Stage 2 – Data Augmentation
# =============================================================================

import os
import cv2
import numpy as np
from pathlib import Path
from typing import Tuple, List, Optional

import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import (
    IMAGE_SIZE, IMAGE_CHANNELS, CLAHE_CLIP, CLAHE_GRID,
    PIXEL_NORM_MAX, AUG_ROTATION, AUG_HFLIP,
    AUG_TRANSLATE, AUG_SCALE, BATCH_SIZE, CLASS_NAMES
)


# =============================================================================
# STAGE 1 – PREPROCESSING UTILITIES
# =============================================================================

def load_image(image_path: str) -> np.ndarray:
    """
    Load an image from disk.

    Supports DICOM (via pydicom), PNG, and JPG formats.

    Parameters
    ----------
    image_path : str
        Full path to the image file.

    Returns
    -------
    np.ndarray
        Raw image array in uint8 format, shape (H, W) or (H, W, 3).
    """
    ext = Path(image_path).suffix.lower()

    if ext == ".dcm":
        try:
            import pydicom
            ds = pydicom.dcmread(image_path)
            img = ds.pixel_array.astype(np.float32)
            # Normalize DICOM pixel values to 0-255
            img = ((img - img.min()) / (img.max() - img.min() + 1e-8) * 255).astype(np.uint8)
        except ImportError:
            raise ImportError(
                "pydicom is required for DICOM support. "
                "Install it with: pip install pydicom"
            )
    else:
        img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        if img is None:
            raise FileNotFoundError(f"Could not read image: {image_path}")

    return img


def apply_clahe(image: np.ndarray) -> np.ndarray:
    """
    Apply Contrast Limited Adaptive Histogram Equalization (CLAHE).

    Enhances visibility of:
    - Joint space narrowing
    - Osteophyte formation
    - Subchondral sclerosis

    Parameters
    ----------
    image : np.ndarray
        Grayscale image in uint8 format.

    Returns
    -------
    np.ndarray
        Contrast-enhanced grayscale image.
    """
    if image.dtype != np.uint8:
        image = image.astype(np.uint8)

    clahe = cv2.createCLAHE(
        clipLimit=CLAHE_CLIP,
        tileGridSize=CLAHE_GRID
    )
    enhanced = clahe.apply(image)
    return enhanced


def pad_and_resize(image: np.ndarray,
                   target_size: Tuple[int, int] = IMAGE_SIZE) -> np.ndarray:
    """
    Pad image to maintain aspect ratio, then resize to target dimensions.

    Preserves anatomical proportions and prevents distortion.

    Parameters
    ----------
    image : np.ndarray
        Input image (grayscale or RGB).
    target_size : tuple
        (width, height) target dimensions.

    Returns
    -------
    np.ndarray
        Padded and resized image.
    """
    h, w = image.shape[:2]
    target_w, target_h = target_size

    # Compute scaling factor preserving aspect ratio
    scale = min(target_w / w, target_h / h)
    new_w = int(w * scale)
    new_h = int(h * scale)

    resized = cv2.resize(image, (new_w, new_h), interpolation=cv2.INTER_AREA)

    # Pad to target size
    delta_w = target_w - new_w
    delta_h = target_h - new_h
    top, bottom = delta_h // 2, delta_h - delta_h // 2
    left, right = delta_w // 2, delta_w - delta_w // 2

    pad_value = 0  # black padding
    padded = cv2.copyMakeBorder(
        resized, top, bottom, left, right,
        cv2.BORDER_CONSTANT, value=pad_value
    )
    return padded


def normalize_image(image: np.ndarray) -> np.ndarray:
    """
    Normalize pixel values to [0, 1] range.

    Parameters
    ----------
    image : np.ndarray
        Input image in uint8 format.

    Returns
    -------
    np.ndarray
        Float32 image normalized to [0, 1].
    """
    return image.astype(np.float32) / PIXEL_NORM_MAX


def to_rgb(image: np.ndarray) -> np.ndarray:
    """
    Convert grayscale image to 3-channel RGB (required by Xception).

    Parameters
    ----------
    image : np.ndarray
        Grayscale image, shape (H, W).

    Returns
    -------
    np.ndarray
        RGB image, shape (H, W, 3).
    """
    if len(image.shape) == 2:
        return np.stack([image] * 3, axis=-1)
    return image


def preprocess_single_image(image_path: str) -> np.ndarray:
    """
    Full preprocessing pipeline for a single image.

    Pipeline:
        Load → CLAHE → Pad & Resize → Normalize → RGB convert

    Parameters
    ----------
    image_path : str
        Path to the input image.

    Returns
    -------
    np.ndarray
        Preprocessed image, shape (224, 224, 3), float32 in [0, 1].
    """
    img = load_image(image_path)
    img = apply_clahe(img)
    img = pad_and_resize(img, IMAGE_SIZE)
    img = normalize_image(img)
    img = to_rgb(img)
    return img


def preprocess_from_bytes(image_bytes: bytes) -> np.ndarray:
    """
    Preprocess an image provided as raw bytes (for Streamlit uploads).

    Parameters
    ----------
    image_bytes : bytes
        Raw image file bytes.

    Returns
    -------
    np.ndarray
        Preprocessed image, shape (224, 224, 3), float32 in [0, 1].
    """
    nparr = np.frombuffer(image_bytes, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise ValueError("Could not decode image from bytes.")

    img = apply_clahe(img)
    img = pad_and_resize(img, IMAGE_SIZE)
    img = normalize_image(img)
    img = to_rgb(img)
    return img


# =============================================================================
# STAGE 2 – DATA AUGMENTATION (Training-time generators)
# =============================================================================

def build_train_generator(train_dir: str,
                           batch_size: int = BATCH_SIZE
                           ) -> tf.keras.preprocessing.image.DirectoryIterator:
    """
    Build training data generator with augmentation.

    Augmentations applied:
    - Rotation ±15°
    - Horizontal flipping
    - Width/height shifts (translation)
    - Zoom (scale)

    Parameters
    ----------
    train_dir : str
        Directory with class sub-folders containing training images.
    batch_size : int
        Mini-batch size.

    Returns
    -------
    DirectoryIterator
        Keras training data generator.
    """
    train_datagen = ImageDataGenerator(
        rotation_range=AUG_ROTATION,
        horizontal_flip=AUG_HFLIP,
        width_shift_range=AUG_TRANSLATE,
        height_shift_range=AUG_TRANSLATE,
        zoom_range=[AUG_SCALE[0], AUG_SCALE[1]],
        fill_mode="nearest",
        rescale=1.0 / PIXEL_NORM_MAX,
        preprocessing_function=_clahe_preprocess
    )

    generator = train_datagen.flow_from_directory(
        train_dir,
        target_size=IMAGE_SIZE,
        color_mode="rgb",
        batch_size=batch_size,
        class_mode="categorical",
        shuffle=True
    )
    return generator


def build_val_generator(val_dir: str,
                         batch_size: int = BATCH_SIZE
                         ) -> tf.keras.preprocessing.image.DirectoryIterator:
    """
    Build validation/test data generator (no augmentation).

    Parameters
    ----------
    val_dir : str
        Directory with class sub-folders containing validation images.
    batch_size : int
        Mini-batch size.

    Returns
    -------
    DirectoryIterator
        Keras validation data generator.
    """
    val_datagen = ImageDataGenerator(
        rescale=1.0 / PIXEL_NORM_MAX,
        preprocessing_function=_clahe_preprocess
    )

    generator = val_datagen.flow_from_directory(
        val_dir,
        target_size=IMAGE_SIZE,
        color_mode="rgb",
        batch_size=batch_size,
        class_mode="categorical",
        shuffle=False
    )
    return generator


def _clahe_preprocess(image: np.ndarray) -> np.ndarray:
    """
    Internal: apply CLAHE inside Keras preprocessing pipeline.
    Expects float32 image scaled to [0, 1]; converts to uint8 for CLAHE.
    """
    # Convert float [0,1] → uint8 [0,255] for CLAHE
    img_uint8 = (image * PIXEL_NORM_MAX).astype(np.uint8)

    # Convert to grayscale if needed
    if img_uint8.ndim == 3:
        gray = cv2.cvtColor(img_uint8, cv2.COLOR_RGB2GRAY)
    else:
        gray = img_uint8

    enhanced = apply_clahe(gray)

    # Convert back to RGB
    rgb = np.stack([enhanced] * 3, axis=-1).astype(np.float32) / PIXEL_NORM_MAX
    return rgb


def get_class_weights(generator) -> dict:
    """
    Compute class weights to handle class imbalance.

    Parameters
    ----------
    generator : DirectoryIterator
        Fitted training generator.

    Returns
    -------
    dict
        Mapping {class_index: weight}.
    """
    from sklearn.utils.class_weight import compute_class_weight

    labels = generator.classes
    unique_classes = np.unique(labels)
    weights = compute_class_weight(
        class_weight="balanced",
        classes=unique_classes,
        y=labels
    )
    return dict(zip(unique_classes, weights))
