#!/usr/bin/env python3
# =============================================================================
# scripts/predict.py
# Single-Image or Batch Inference Script
# =============================================================================
# Runs inference on one or more knee X-ray images and produces:
# - Console output with KL grade + confidence
# - Grad-CAM visualizations saved to disk
# - Optional JSON output of all results
#
# Usage (single image):
#   python scripts/predict.py --image path/to/xray.jpg \
#       --checkpoint checkpoints/xception_knee_oa_phase2_best.keras
#
# Usage (batch):
#   python scripts/predict.py --dir path/to/images/ \
#       --checkpoint checkpoints/xception_knee_oa_phase2_best.keras \
#       --output_dir reports/predictions/
#
# =============================================================================

import os
import sys
import json
import argparse
import glob
from pathlib import Path
from typing import List

import numpy as np

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

from config import CLASS_NAMES, REPORTS_DIR
from data  import preprocess_single_image
from model import load_model, GradCAM, create_gradcam_figure, save_gradcam_figure
from utils import format_prediction, get_clinical_description


SUPPORTED_EXT = [".jpg", ".jpeg", ".png", ".dcm", ".bmp"]


# =============================================================================
# SINGLE PREDICTION
# =============================================================================

def predict_single(image_path: str,
                    model,
                    gradcam: GradCAM,
                    output_dir: str = None,
                    verbose: bool = True) -> dict:
    """
    Run inference on a single image.

    Parameters
    ----------
    image_path : str
    model : tf.keras.Model
    gradcam : GradCAM
    output_dir : str, optional
        If provided, save Grad-CAM figure here.
    verbose : bool

    Returns
    -------
    dict
        Prediction result dictionary.
    """
    # Preprocess
    preprocessed = preprocess_single_image(image_path)

    # Inference + Grad-CAM
    heatmap, overlay, predicted_class, probabilities = gradcam.generate(preprocessed)

    # Format results
    prediction = format_prediction(predicted_class, probabilities)
    prediction["image_path"] = image_path
    prediction["clinical"] = get_clinical_description(predicted_class)

    if verbose:
        _print_result(image_path, prediction)

    # Save Grad-CAM figure
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        stem = Path(image_path).stem
        fig_path = os.path.join(output_dir, f"{stem}_gradcam.png")
        fig = create_gradcam_figure(
            preprocessed, heatmap, overlay, predicted_class, probabilities
        )
        save_gradcam_figure(fig, fig_path)
        prediction["gradcam_path"] = fig_path

    return prediction


def _print_result(image_path: str, prediction: dict) -> None:
    """Print formatted prediction result to console."""
    divider = "─" * 55
    print(f"\n{divider}")
    print(f"  Image     : {os.path.basename(image_path)}")
    print(f"  KL Grade  : Grade {prediction['kl_grade']}")
    print(f"  Diagnosis : {prediction['grade_name']}")
    print(f"  Severity  : {prediction['severity']}")
    print(f"  Confidence: {prediction['confidence_pct']}")
    print(f"\n  Probabilities:")
    for name, prob in prediction["probabilities"].items():
        marker = " ◀" if CLASS_NAMES[prediction["kl_grade"]] == name else ""
        bar_len = int(prob * 30)
        bar = "█" * bar_len + "░" * (30 - bar_len)
        print(f"    {name:<25} [{bar}] {prob:.1%}{marker}")
    print(f"{divider}")


# =============================================================================
# BATCH PREDICTION
# =============================================================================

def predict_batch(image_paths: List[str],
                   model,
                   gradcam: GradCAM,
                   output_dir: str = None,
                   save_json: bool = True) -> List[dict]:
    """
    Run inference on a list of images.

    Parameters
    ----------
    image_paths : list of str
    model : tf.keras.Model
    gradcam : GradCAM
    output_dir : str, optional
    save_json : bool

    Returns
    -------
    list of dict
        All prediction results.
    """
    results = []
    n = len(image_paths)

    print(f"\n[INFO] Running batch inference on {n} images...\n")

    for i, path in enumerate(image_paths, 1):
        print(f"[{i:3d}/{n}] {os.path.basename(path)}", end=" ... ")
        try:
            result = predict_single(path, model, gradcam, output_dir, verbose=False)
            results.append(result)
            print(f"Grade {result['kl_grade']} ({result['confidence_pct']})")
        except Exception as e:
            print(f"ERROR: {e}")
            results.append({"image_path": path, "error": str(e)})

    # Summary
    successful = [r for r in results if "error" not in r]
    grade_counts = {}
    for r in successful:
        g = r["kl_grade"]
        grade_counts[g] = grade_counts.get(g, 0) + 1

    print(f"\n{'─'*55}")
    print(f"  BATCH SUMMARY")
    print(f"  Total    : {n}")
    print(f"  Success  : {len(successful)}")
    print(f"  Failed   : {n - len(successful)}")
    print(f"\n  Grade Distribution:")
    for g in sorted(grade_counts):
        print(f"    KL {g}: {grade_counts[g]} images")
    print(f"{'─'*55}\n")

    # Save JSON
    if save_json and output_dir:
        json_path = os.path.join(output_dir, "batch_predictions.json")
        with open(json_path, "w") as f:
            json.dump(results, f, indent=2, default=str)
        print(f"[INFO] Results saved: {json_path}")

    return results


# =============================================================================
# CLI
# =============================================================================

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run Xception Knee OA inference on images"
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--image", type=str, help="Path to single image")
    group.add_argument("--dir",   type=str, help="Directory of images for batch inference")

    parser.add_argument(
        "--checkpoint", type=str, required=True,
        help="Path to trained model checkpoint"
    )
    parser.add_argument(
        "--output_dir", type=str,
        default=os.path.join(REPORTS_DIR, "predictions"),
        help="Directory to save Grad-CAM figures and JSON"
    )
    parser.add_argument(
        "--no_save", action="store_true",
        help="Skip saving output files"
    )
    return parser.parse_args()


def main():
    import tensorflow as tf
    tf.get_logger().setLevel("ERROR")

    args = parse_args()
    output_dir = None if args.no_save else args.output_dir

    # Load model
    print(f"\n[INFO] Loading model: {args.checkpoint}")
    model  = load_model(args.checkpoint)
    gradcam = GradCAM(model)
    print("[INFO] Model ready.\n")

    if args.image:
        # Single image
        predict_single(args.image, model, gradcam, output_dir, verbose=True)
    else:
        # Batch
        image_paths = []
        for ext in SUPPORTED_EXT:
            image_paths.extend(
                glob.glob(os.path.join(args.dir, f"*{ext}"))
            )
            image_paths.extend(
                glob.glob(os.path.join(args.dir, f"*{ext.upper()}"))
            )
        image_paths = sorted(set(image_paths))

        if not image_paths:
            print(f"[ERROR] No supported images found in: {args.dir}")
            sys.exit(1)

        predict_batch(image_paths, model, gradcam, output_dir)


if __name__ == "__main__":
    main()
