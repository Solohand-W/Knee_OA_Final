#!/usr/bin/env python3
# =============================================================================
# scripts/prepare_dataset.py
# Dataset Preparation Utility
# =============================================================================
# This script organizes raw knee X-ray images into the expected directory
# structure for training, validation, and test splits.
#
# Expected raw dataset structure:
#   data_raw/
#     ├── 0/    (all KL Grade 0 images)
#     ├── 1/    (all KL Grade 1 images)
#     ├── 2/    (all KL Grade 2 images)
#     ├── 3/    (all KL Grade 3 images)
#     └── 4/    (all KL Grade 4 images)
#
# Compatible with the OAI (Osteoarthritis Initiative) and
# MOST (Multicenter Osteoarthritis Study) datasets, as well as
# the Kaggle Knee OA dataset.
#
# Usage:
#   python scripts/prepare_dataset.py --src data_raw/all --dst data_raw \
#       --train 0.7 --val 0.15 --test 0.15 --seed 42
#
# =============================================================================

import os
import sys
import shutil
import argparse
import random
from pathlib import Path
from typing import List, Tuple

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import CLASS_NAMES


SUPPORTED_EXT = {".jpg", ".jpeg", ".png", ".dcm", ".bmp"}


def collect_images(src_dir: str) -> dict:
    """
    Collect all image paths grouped by class folder.

    Parameters
    ----------
    src_dir : str
        Source directory with class sub-folders (0, 1, 2, 3, 4).

    Returns
    -------
    dict
        {class_name: [list of image paths]}
    """
    dataset = {}
    for cls in sorted(os.listdir(src_dir)):
        cls_path = os.path.join(src_dir, cls)
        if not os.path.isdir(cls_path):
            continue
        images = [
            os.path.join(cls_path, f)
            for f in os.listdir(cls_path)
            if Path(f).suffix.lower() in SUPPORTED_EXT
        ]
        if images:
            dataset[cls] = images
            print(f"  Class {cls}: {len(images)} images")
    return dataset


def split_dataset(images: List[str],
                   train_ratio: float = 0.7,
                   val_ratio: float = 0.15,
                   seed: int = 42) -> Tuple[List, List, List]:
    """
    Randomly split images into train / val / test.

    Parameters
    ----------
    images : list of str
        Full paths to all images of one class.
    train_ratio : float
    val_ratio : float
    seed : int

    Returns
    -------
    train, val, test lists
    """
    random.seed(seed)
    shuffled = images.copy()
    random.shuffle(shuffled)

    n = len(shuffled)
    n_train = int(n * train_ratio)
    n_val   = int(n * val_ratio)

    train = shuffled[:n_train]
    val   = shuffled[n_train:n_train + n_val]
    test  = shuffled[n_train + n_val:]

    return train, val, test


def copy_split(images: List[str],
                dst_dir: str,
                cls: str,
                split: str,
                dry_run: bool = False) -> int:
    """
    Copy images to destination split directory.

    Parameters
    ----------
    images : list of str
    dst_dir : str
        Root dataset directory.
    cls : str
        Class name (0-4).
    split : str
        One of "train", "val", "test".
    dry_run : bool

    Returns
    -------
    int
        Number of files copied.
    """
    split_cls_dir = os.path.join(dst_dir, split, cls)
    os.makedirs(split_cls_dir, exist_ok=True)

    for src_path in images:
        dst_path = os.path.join(split_cls_dir, os.path.basename(src_path))
        if not dry_run:
            shutil.copy2(src_path, dst_path)

    return len(images)


def prepare_dataset(src_dir: str,
                     dst_dir: str,
                     train_ratio: float = 0.70,
                     val_ratio: float   = 0.15,
                     test_ratio: float  = 0.15,
                     seed: int = 42,
                     dry_run: bool = False) -> None:
    """
    Full dataset preparation pipeline.

    Parameters
    ----------
    src_dir : str
        Source directory containing class sub-folders.
    dst_dir : str
        Destination root (train/val/test sub-dirs will be created here).
    train_ratio, val_ratio, test_ratio : float
        Split ratios (must sum to 1.0).
    seed : int
        Random seed.
    dry_run : bool
        If True, only print actions without copying files.
    """
    assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6, \
        "Split ratios must sum to 1.0"

    print("\n" + "=" * 60)
    print("  DATASET PREPARATION")
    print("=" * 60)
    print(f"  Source : {src_dir}")
    print(f"  Dest   : {dst_dir}")
    print(f"  Splits : train={train_ratio:.0%}  val={val_ratio:.0%}  test={test_ratio:.0%}")
    print(f"  Seed   : {seed}")
    if dry_run:
        print("  ** DRY RUN – no files will be copied **")
    print("-" * 60)

    # Collect
    print("\n[INFO] Scanning source directory...")
    dataset = collect_images(src_dir)

    if not dataset:
        print("[ERROR] No valid class directories found in:", src_dir)
        return

    # Split and copy
    total = {"train": 0, "val": 0, "test": 0}

    for cls, images in dataset.items():
        train, val, test = split_dataset(images, train_ratio, val_ratio, seed)
        for split_name, split_images in [("train", train), ("val", val), ("test", test)]:
            n = copy_split(split_images, dst_dir, cls, split_name, dry_run)
            total[split_name] += n

    print("\n[SUMMARY]")
    print(f"  Training   : {total['train']} images")
    print(f"  Validation : {total['val']} images")
    print(f"  Test       : {total['test']} images")
    print(f"  Total      : {sum(total.values())} images")
    print("\n[INFO] Dataset preparation complete.")
    print(f"[INFO] Structure saved to: {dst_dir}/train | val | test")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Prepare knee OA dataset directory structure"
    )
    parser.add_argument("--src",   type=str, required=True,
                        help="Source directory with class sub-folders")
    parser.add_argument("--dst",   type=str, default="data_raw",
                        help="Destination root directory")
    parser.add_argument("--train", type=float, default=0.70)
    parser.add_argument("--val",   type=float, default=0.15)
    parser.add_argument("--test",  type=float, default=0.15)
    parser.add_argument("--seed",  type=int, default=42)
    parser.add_argument("--dry_run", action="store_true",
                        help="Preview without copying files")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    prepare_dataset(
        src_dir=args.src,
        dst_dir=args.dst,
        train_ratio=args.train,
        val_ratio=args.val,
        test_ratio=args.test,
        seed=args.seed,
        dry_run=args.dry_run
    )
