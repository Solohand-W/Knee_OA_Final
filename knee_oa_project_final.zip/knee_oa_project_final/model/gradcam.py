# =============================================================================
# model/gradcam.py
# Stage 8 – Explainability Module (Grad-CAM)
# =============================================================================
# Gradient-weighted Class Activation Mapping (Grad-CAM) generates visual
# explanations for model predictions by highlighting the regions in the
# input image most influential to the classification decision.
# =============================================================================

import os
import sys
import cv2
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from typing import Tuple, Optional

import tensorflow as tf

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import GRADCAM_ALPHA, IMAGE_SIZE, CLASS_NAMES
from model.xception_model import get_gradcam_layer


# =============================================================================
# GRAD-CAM CORE
# =============================================================================

class GradCAM:
    """
    Grad-CAM: Gradient-weighted Class Activation Mapping.

    How it works
    ------------
    1. Forward-pass the input image through the model.
    2. Extract the feature maps from the target convolutional layer.
    3. Compute gradients of the predicted class score w.r.t. feature maps.
    4. Pool gradients globally (Global Average Pooling over spatial dims).
    5. Weight each feature map by its corresponding pooled gradient.
    6. Sum weighted feature maps → class activation map.
    7. Apply ReLU (retain only positive activations).
    8. Upsample to input resolution.
    9. Overlay heatmap on original X-ray image.

    Parameters
    ----------
    model : tf.keras.Model
        Trained classification model.
    layer_name : str
        Name of the target convolutional layer.
    """

    def __init__(self, model: tf.keras.Model, layer_name: str = None):
        self.model = model
        self.layer_name = layer_name or get_gradcam_layer(model)
        self._build_grad_model()

    def _build_grad_model(self) -> None:
        """Build a sub-model that outputs both the target layer and predictions."""
        try:
            target_layer = self.model.get_layer(self.layer_name)
        except ValueError:
            raise ValueError(
                f"Layer '{self.layer_name}' not found in model. "
                f"Available layers: {[l.name for l in self.model.layers]}"
            )

        self.grad_model = tf.keras.Model(
            inputs=self.model.inputs,
            outputs=[target_layer.output, self.model.output]
        )

    def compute_heatmap(self,
                         image: np.ndarray,
                         class_idx: Optional[int] = None,
                         eps: float = 1e-8) -> Tuple[np.ndarray, int, np.ndarray]:
        """
        Compute the Grad-CAM heatmap for a single image.

        Parameters
        ----------
        image : np.ndarray
            Preprocessed image, shape (224, 224, 3), float32 in [0, 1].
        class_idx : int, optional
            Target class index. If None, uses the predicted class.
        eps : float
            Small value for numerical stability.

        Returns
        -------
        heatmap : np.ndarray
            Grad-CAM heatmap, shape (224, 224), values in [0, 1].
        class_idx : int
            Class index used to compute Grad-CAM.
        probabilities : np.ndarray
            Model output probabilities, shape (num_classes,).
        """
        # Expand image to batch
        img_batch = np.expand_dims(image, axis=0).astype(np.float32)

        with tf.GradientTape() as tape:
            tape.watch(img_batch)
            feature_maps, predictions = self.grad_model(img_batch)
            probabilities = predictions[0].numpy()

            if class_idx is None:
                class_idx = int(np.argmax(probabilities))

            # Score for the target class
            class_score = predictions[:, class_idx]

        # Compute gradients of class score w.r.t. feature maps
        gradients = tape.gradient(class_score, feature_maps)

        # Pool gradients over spatial dimensions (Global Average Pooling)
        pooled_gradients = tf.reduce_mean(gradients, axis=(0, 1, 2))

        # Weight feature maps by pooled gradients
        feature_maps = feature_maps[0]                    # (H, W, C)
        weighted_maps = feature_maps * pooled_gradients  # broadcast over channels

        # Sum weighted feature maps → raw activation map
        cam = tf.reduce_sum(weighted_maps, axis=-1).numpy()  # (H, W)

        # Apply ReLU – retain only positive activations
        cam = np.maximum(cam, 0)

        # Normalize to [0, 1]
        cam = (cam - cam.min()) / (cam.max() - cam.min() + eps)

        # Upsample to input resolution
        cam = cv2.resize(cam, IMAGE_SIZE, interpolation=cv2.INTER_LINEAR)

        return cam, class_idx, probabilities

    def overlay_heatmap(self,
                         heatmap: np.ndarray,
                         original_image: np.ndarray,
                         alpha: float = GRADCAM_ALPHA,
                         colormap: int = cv2.COLORMAP_JET) -> np.ndarray:
        """
        Overlay Grad-CAM heatmap on the original X-ray image.

        Parameters
        ----------
        heatmap : np.ndarray
            Grad-CAM heatmap, shape (H, W), values in [0, 1].
        original_image : np.ndarray
            Original image, shape (H, W, 3), values in [0, 1].
        alpha : float
            Transparency of the heatmap overlay (0 = invisible, 1 = opaque).
        colormap : int
            OpenCV colormap to use.

        Returns
        -------
        np.ndarray
            Overlay image, shape (H, W, 3), uint8.
        """
        # Convert heatmap to uint8 and apply colormap
        heatmap_uint8 = (heatmap * 255).astype(np.uint8)
        colored_heatmap = cv2.applyColorMap(heatmap_uint8, colormap)
        colored_heatmap = cv2.cvtColor(colored_heatmap, cv2.COLOR_BGR2RGB)

        # Convert original image to uint8
        if original_image.max() <= 1.0:
            orig_uint8 = (original_image * 255).astype(np.uint8)
        else:
            orig_uint8 = original_image.astype(np.uint8)

        # Ensure same shape
        if orig_uint8.shape[:2] != colored_heatmap.shape[:2]:
            colored_heatmap = cv2.resize(
                colored_heatmap,
                (orig_uint8.shape[1], orig_uint8.shape[0])
            )

        # Weighted overlay
        overlay = cv2.addWeighted(orig_uint8, 1 - alpha,
                                   colored_heatmap, alpha, 0)
        return overlay

    def generate(self,
                  image: np.ndarray,
                  class_idx: Optional[int] = None
                  ) -> Tuple[np.ndarray, np.ndarray, int, np.ndarray]:
        """
        Full Grad-CAM pipeline: compute heatmap + overlay.

        Parameters
        ----------
        image : np.ndarray
            Preprocessed image (224, 224, 3), float32.
        class_idx : int, optional
            Target class. Defaults to predicted class.

        Returns
        -------
        heatmap : np.ndarray
            Raw normalized heatmap (224, 224).
        overlay : np.ndarray
            Heatmap overlaid on original image (224, 224, 3), uint8.
        predicted_class : int
            Predicted KL grade.
        probabilities : np.ndarray
            Class probabilities (5,).
        """
        heatmap, predicted_class, probabilities = self.compute_heatmap(
            image, class_idx
        )
        overlay = self.overlay_heatmap(heatmap, image)
        return heatmap, overlay, predicted_class, probabilities


# =============================================================================
# VISUALIZATION UTILITIES
# =============================================================================

def create_gradcam_figure(original_image: np.ndarray,
                           heatmap: np.ndarray,
                           overlay: np.ndarray,
                           predicted_class: int,
                           probabilities: np.ndarray,
                           figsize: Tuple[int, int] = (16, 5)) -> plt.Figure:
    """
    Create a side-by-side Grad-CAM visualization figure.

    Layout:
        [Original X-ray] | [Grad-CAM Heatmap] | [Overlay] | [Probability Bar Chart]

    Parameters
    ----------
    original_image : np.ndarray
        Original preprocessed image (224, 224, 3).
    heatmap : np.ndarray
        Normalized Grad-CAM heatmap (224, 224).
    overlay : np.ndarray
        Heatmap overlaid image (224, 224, 3).
    predicted_class : int
        Predicted KL grade index.
    probabilities : np.ndarray
        Softmax probabilities (5,).
    figsize : tuple
        Figure size.

    Returns
    -------
    matplotlib.figure.Figure
    """
    fig, axes = plt.subplots(1, 4, figsize=figsize)
    fig.patch.set_facecolor("#0e1117")

    _ax_style = dict(facecolor="#0e1117")

    # ── Panel 1: Original X-ray
    ax = axes[0]
    ax.set(**_ax_style)
    img_display = (original_image * 255).astype(np.uint8) if original_image.max() <= 1.0 \
        else original_image.astype(np.uint8)
    ax.imshow(img_display[:, :, 0], cmap="gray")
    ax.set_title("Original X-ray", color="white", fontsize=11, fontweight="bold")
    ax.axis("off")

    # ── Panel 2: Raw Grad-CAM Heatmap
    ax = axes[1]
    ax.set(**_ax_style)
    im = ax.imshow(heatmap, cmap="jet")
    ax.set_title("Grad-CAM Heatmap", color="white", fontsize=11, fontweight="bold")
    ax.axis("off")
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    # ── Panel 3: Overlay
    ax = axes[2]
    ax.set(**_ax_style)
    ax.imshow(overlay)
    grade_label = CLASS_NAMES.get(predicted_class, f"Grade {predicted_class}")
    ax.set_title(f"Overlay – {grade_label}", color="#00d4ff",
                  fontsize=10, fontweight="bold")
    ax.axis("off")

    # ── Panel 4: Probability Bar Chart
    ax = axes[3]
    ax.set_facecolor("#1a1d2e")
    labels = [f"KL {i}" for i in range(len(probabilities))]
    colors = ["#e74c3c" if i == predicted_class else "#3498db"
              for i in range(len(probabilities))]
    bars = ax.barh(labels, probabilities, color=colors, edgecolor="white",
                   linewidth=0.5)
    ax.set_xlim(0, 1)
    ax.set_xlabel("Probability", color="white")
    ax.set_title("Class Probabilities", color="white", fontsize=11,
                  fontweight="bold")
    ax.tick_params(colors="white")
    for spine in ax.spines.values():
        spine.set_edgecolor("#444")
    # Annotate bars
    for bar, prob in zip(bars, probabilities):
        ax.text(min(prob + 0.02, 0.92), bar.get_y() + bar.get_height() / 2,
                f"{prob:.1%}", va="center", color="white", fontsize=9)

    plt.tight_layout(pad=1.5)
    return fig


def save_gradcam_figure(fig: plt.Figure, output_path: str) -> None:
    """Save Grad-CAM figure to disk."""
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close(fig)
    print(f"[INFO] Grad-CAM figure saved: {output_path}")
