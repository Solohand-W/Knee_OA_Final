# =============================================================================
# model/xception_model.py
# Stage 3 – Feature Extraction (Xception Backbone)
# Stage 4 – Global Feature Representation (GAP)
# Stage 5 – Diagnostic Classification
# =============================================================================

import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import (
    IMAGE_SIZE, IMAGE_CHANNELS, NUM_CLASSES,
    DROPOUT_RATE, LEARNING_RATE, LOSS_FUNCTION,
    CHECKPOINT_DIR, GRADCAM_LAYER
)

import tensorflow as tf
from tensorflow.keras import Model, Input
from tensorflow.keras.applications import Xception
from tensorflow.keras.layers import (
    GlobalAveragePooling2D, Dense, Dropout, BatchNormalization
)
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import (
    ModelCheckpoint, EarlyStopping, ReduceLROnPlateau,
    TensorBoard, CSVLogger
)


# =============================================================================
# MODEL BUILDER
# =============================================================================

def build_xception_model(num_classes: int = NUM_CLASSES,
                          dropout_rate: float = DROPOUT_RATE,
                          learning_rate: float = LEARNING_RATE,
                          fine_tune_from: int = None) -> tf.keras.Model:
    """
    Build the Xception-based knee OA classification model.

    Architecture
    ------------
    Input (224×224×3)
        → Xception backbone (pretrained ImageNet, 36 conv layers)
            • Depthwise separable convolutions
            • Residual connections
        → Global Average Pooling (Stage 4)
        → BatchNorm → Dense(512, ReLU) → Dropout(0.5)
        → BatchNorm → Dense(256, ReLU) → Dropout(0.5)
        → Dense(num_classes, Softmax)   (Stage 5)

    Parameters
    ----------
    num_classes : int
        Number of output classes (default 5 for KL grades 0-4).
    dropout_rate : float
        Dropout probability applied after each Dense layer.
    learning_rate : float
        Initial Adam learning rate.
    fine_tune_from : int, optional
        If set, unfreeze all layers from this index onward for fine-tuning.
        Pass None to keep entire backbone frozen (feature extraction only).

    Returns
    -------
    tf.keras.Model
        Compiled Keras model.
    """
    input_shape = IMAGE_SIZE + (IMAGE_CHANNELS,)
    inputs = Input(shape=input_shape, name="input_image")

    # ------------------------------------------------------------------
    # STAGE 3: Feature Extraction – Xception Backbone
    # ------------------------------------------------------------------
    backbone = Xception(
        include_top=False,            # Remove ImageNet classification head
        weights="imagenet",           # Transfer learning from ImageNet
        input_tensor=inputs,
        pooling=None
    )

    # Freeze backbone layers initially (transfer learning phase)
    backbone.trainable = False

    x = backbone.output   # shape: (7, 7, 2048) for 224×224 input

    # ------------------------------------------------------------------
    # STAGE 4: Global Feature Representation – Global Average Pooling
    # ------------------------------------------------------------------
    x = GlobalAveragePooling2D(name="global_average_pooling")(x)
    # Output shape: (2048,) – compact 1D feature vector

    # ------------------------------------------------------------------
    # STAGE 5: Diagnostic Classification
    # ------------------------------------------------------------------
    # Fully Connected Block 1
    x = BatchNormalization(name="bn_1")(x)
    x = Dense(512, activation="relu", name="dense_512")(x)
    x = Dropout(dropout_rate, name="dropout_1")(x)

    # Fully Connected Block 2
    x = BatchNormalization(name="bn_2")(x)
    x = Dense(256, activation="relu", name="dense_256")(x)
    x = Dropout(dropout_rate, name="dropout_2")(x)

    # Output layer – Softmax over KL grades
    outputs = Dense(num_classes, activation="softmax", name="predictions")(x)

    model = Model(inputs=inputs, outputs=outputs,
                  name="XceptionKneeOA")

    # ------------------------------------------------------------------
    # Fine-tuning: optionally unfreeze top layers of backbone
    # ------------------------------------------------------------------
    if fine_tune_from is not None:
        backbone.trainable = True
        for layer in backbone.layers[:fine_tune_from]:
            layer.trainable = False

    # ------------------------------------------------------------------
    # Compile
    # ------------------------------------------------------------------
    model.compile(
        optimizer=Adam(learning_rate=learning_rate),
        loss=LOSS_FUNCTION,
        metrics=["accuracy",
                 tf.keras.metrics.AUC(name="auc"),
                 tf.keras.metrics.Precision(name="precision"),
                 tf.keras.metrics.Recall(name="recall")]
    )

    return model


# =============================================================================
# CALLBACKS
# =============================================================================

def get_callbacks(model_name: str = "xception_knee_oa",
                  monitor: str = "val_accuracy") -> list:
    """
    Build standard training callbacks.

    Includes:
    - ModelCheckpoint  (saves best weights)
    - EarlyStopping    (stops when val_accuracy plateaus)
    - ReduceLROnPlateau
    - TensorBoard
    - CSVLogger

    Parameters
    ----------
    model_name : str
        Base name for checkpoint files.
    monitor : str
        Metric to monitor for checkpointing and early stopping.

    Returns
    -------
    list of tf.keras.callbacks.Callback
    """
    from config import (EARLY_STOP_PATIENCE, LR_REDUCE_PATIENCE,
                        LR_REDUCE_FACTOR, MIN_LR, LOG_DIR)

    checkpoint_path = os.path.join(CHECKPOINT_DIR, f"{model_name}_best.keras")
    log_path = os.path.join(LOG_DIR, model_name)
    csv_path = os.path.join(LOG_DIR, f"{model_name}_training_log.csv")

    callbacks = [
        ModelCheckpoint(
            filepath=checkpoint_path,
            monitor=monitor,
            save_best_only=True,
            save_weights_only=False,
            verbose=1
        ),
        EarlyStopping(
            monitor=monitor,
            patience=EARLY_STOP_PATIENCE,
            restore_best_weights=True,
            verbose=1
        ),
        ReduceLROnPlateau(
            monitor="val_loss",
            factor=LR_REDUCE_FACTOR,
            patience=LR_REDUCE_PATIENCE,
            min_lr=MIN_LR,
            verbose=1
        ),
        TensorBoard(
            log_dir=log_path,
            histogram_freq=1
        ),
        CSVLogger(csv_path, append=True)
    ]

    return callbacks


# =============================================================================
# MODEL LOADING UTILITIES
# =============================================================================

def load_model(checkpoint_path: str) -> tf.keras.Model:
    """
    Load a saved Keras model from a checkpoint.

    Parameters
    ----------
    checkpoint_path : str
        Path to .keras or .h5 model file.

    Returns
    -------
    tf.keras.Model
    """
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

    model = tf.keras.models.load_model(checkpoint_path)
    print(f"[INFO] Model loaded from: {checkpoint_path}")
    return model


def get_gradcam_layer(model: tf.keras.Model,
                       layer_name: str = GRADCAM_LAYER) -> str:
    """
    Verify and return the Grad-CAM target layer name.

    Falls back to the last Conv layer if named layer not found.

    Parameters
    ----------
    model : tf.keras.Model
    layer_name : str

    Returns
    -------
    str
        Validated layer name.
    """
    layer_names = [l.name for l in model.layers]

    if layer_name in layer_names:
        return layer_name

    # Fallback: find last convolutional layer
    for layer in reversed(model.layers):
        if isinstance(layer, (tf.keras.layers.Conv2D,
                               tf.keras.layers.SeparableConv2D,
                               tf.keras.layers.DepthwiseConv2D,
                               tf.keras.layers.Activation)):
            print(f"[WARN] '{layer_name}' not found. "
                  f"Using fallback: '{layer.name}'")
            return layer.name

    raise ValueError("No suitable Grad-CAM layer found in model.")


def model_summary_string(model: tf.keras.Model) -> str:
    """Return model summary as a plain string."""
    lines = []
    model.summary(print_fn=lambda x: lines.append(x))
    return "\n".join(lines)
