# =============================================================================
# app.py
# Stage 9 – User Interface and Deployment (Streamlit Dashboard)
# XCEPTION-BASED DEEP LEARNING FRAMEWORK FOR KNEE OSTEOARTHRITIS
# CLASSIFICATION WITH GRAD-CAM INTERPRETATION
# =============================================================================
#
# Run with:
#   streamlit run app.py
#
# =============================================================================

import os
import io
import sys
import time
import warnings
warnings.filterwarnings("ignore")
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

import numpy as np
import streamlit as st
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import (
    CHECKPOINT_DIR, CLASS_NAMES, NUM_CLASSES,
    IMAGE_SIZE, GRADCAM_LAYER
)
from data  import preprocess_from_bytes
from model import GradCAM, create_gradcam_figure
from utils import (
    format_prediction,
    get_clinical_description,
    fig_to_bytes,
    generate_pdf_report,
)


# =============================================================================
# PAGE CONFIG
# =============================================================================

st.set_page_config(
    page_title="Knee OA Classifier",
    page_icon="🦴",
    layout="wide",
    initial_sidebar_state="expanded",
)

# =============================================================================
# CUSTOM CSS
# =============================================================================

st.markdown("""
<style>
    /* Main background */
    .stApp { background-color: #0e1117; }

    /* Card style */
    .metric-card {
        background: linear-gradient(135deg, #1a1d2e 0%, #16213e 100%);
        border: 1px solid #00d4ff33;
        border-radius: 12px;
        padding: 20px;
        margin: 8px 0;
        text-align: center;
    }
    .metric-card h2 { color: #00d4ff; margin: 0; font-size: 2rem; }
    .metric-card p  { color: #aaa; margin: 4px 0 0 0; font-size: 0.9rem; }

    /* Grade badge */
    .grade-badge {
        display: inline-block;
        padding: 8px 24px;
        border-radius: 30px;
        font-size: 1.3rem;
        font-weight: bold;
        margin: 8px 0;
    }

    /* Section headers */
    .section-header {
        color: #00d4ff;
        font-size: 1.1rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        border-bottom: 1px solid #00d4ff44;
        padding-bottom: 6px;
        margin-top: 16px;
        margin-bottom: 12px;
    }

    /* Disclaimer box */
    .disclaimer {
        background: #1a0a0a;
        border-left: 4px solid #e74c3c;
        padding: 10px 14px;
        border-radius: 4px;
        font-size: 0.82rem;
        color: #bbb;
        margin-top: 16px;
    }

    /* Probability bar row */
    .prob-row {
        display: flex;
        align-items: center;
        margin: 4px 0;
        gap: 8px;
    }

    /* Upload area */
    .uploadedFile { border: 2px dashed #00d4ff44 !important; border-radius: 10px !important; }

    /* Hide Streamlit branding */
    #MainMenu { visibility: hidden; }
    footer     { visibility: hidden; }
    header     { visibility: hidden; }
</style>
""", unsafe_allow_html=True)


# =============================================================================
# CACHED MODEL LOADER
# =============================================================================

@st.cache_resource(show_spinner=False)
def load_model_cached(checkpoint_path: str):
    """Load and cache the trained model + GradCAM wrapper."""
    import tensorflow as tf
    tf.get_logger().setLevel("ERROR")

    if not os.path.exists(checkpoint_path):
        return None, None

    from model import load_model as _load
    model = _load(checkpoint_path)
    gradcam = GradCAM(model, GRADCAM_LAYER)
    return model, gradcam


# =============================================================================
# SIDEBAR
# =============================================================================

def render_sidebar() -> str:
    """Render sidebar and return selected checkpoint path."""

    st.sidebar.markdown("""
    <div style='text-align:center; padding: 16px 0'>
        <span style='font-size:2.5rem'>🦴</span>
        <h3 style='color:#00d4ff; margin:4px 0'>Knee OA Classifier</h3>
        <p style='color:#888; font-size:0.8rem'>Xception + Grad-CAM</p>
    </div>
    """, unsafe_allow_html=True)

    st.sidebar.markdown("---")
    st.sidebar.markdown("### ⚙️ Configuration")

    # Checkpoint selector
    checkpoint_dir = CHECKPOINT_DIR
    checkpoints = []
    if os.path.isdir(checkpoint_dir):
        checkpoints = [
            f for f in os.listdir(checkpoint_dir)
            if f.endswith((".keras", ".h5"))
        ]

    if checkpoints:
        selected = st.sidebar.selectbox(
            "Model Checkpoint",
            checkpoints,
            index=0
        )
        checkpoint_path = os.path.join(checkpoint_dir, selected)
    else:
        checkpoint_path = st.sidebar.text_input(
            "Checkpoint Path",
            placeholder="checkpoints/model_best.keras"
        )
        if not checkpoint_path:
            st.sidebar.warning("⚠ No checkpoint found. Please train the model first.")

    st.sidebar.markdown("---")
    st.sidebar.markdown("### 📋 KL Grading Scale")
    grade_colors = ["#2ecc71", "#f1c40f", "#f39c12", "#e67e22", "#e74c3c"]
    for i, (name, color) in enumerate(zip(CLASS_NAMES.values(), grade_colors)):
        st.sidebar.markdown(
            f"<span style='color:{color}'>●</span> **{name}**",
            unsafe_allow_html=True
        )

    st.sidebar.markdown("---")
    st.sidebar.markdown("### 📌 About")
    st.sidebar.markdown("""
    <div style='color:#888; font-size:0.8rem; line-height:1.5'>
    This system uses a deep learning model based on the Xception architecture
    pretrained on ImageNet, fine-tuned for knee OA severity classification
    using the Kellgren-Lawrence (KL) grading system.
    <br><br>
    <b style='color:#00d4ff'>Grad-CAM</b> highlights the regions of the
    X-ray image that influenced the model's decision.
    </div>
    """, unsafe_allow_html=True)

    return checkpoint_path


# =============================================================================
# MAIN PAGE
# =============================================================================

def main():
    # ── Title
    st.markdown("""
    <div style='text-align:center; padding: 20px 0 10px 0'>
        <h1 style='color:#00d4ff; font-size:2rem; margin:0'>
            🦴 Knee Osteoarthritis Classification
        </h1>
        <p style='color:#aaa; font-size:1rem; margin:6px 0 0 0'>
            Xception-Based Deep Learning Framework with Grad-CAM Interpretation
        </p>
    </div>
    """, unsafe_allow_html=True)
    st.markdown("---")

    # ── Sidebar
    checkpoint_path = render_sidebar()

    # ── Load model
    model, gradcam = None, None
    model_loaded = False

    if checkpoint_path and os.path.exists(checkpoint_path):
        with st.spinner("🔄 Loading model..."):
            model, gradcam = load_model_cached(checkpoint_path)
        if model is not None:
            model_loaded = True
            st.success("✅ Model loaded successfully")
        else:
            st.error("❌ Failed to load model checkpoint.")
    else:
        st.info("ℹ️ Please provide a valid model checkpoint to begin.")

    # ── Upload section
    st.markdown('<div class="section-header">📂 Upload Knee X-ray</div>',
                unsafe_allow_html=True)

    uploaded_file = st.file_uploader(
        "Upload a knee radiograph (JPG, PNG, or DICOM)",
        type=["jpg", "jpeg", "png", "dcm"],
        help="Accepted formats: JPEG, PNG, DICOM (.dcm)"
    )

    if uploaded_file is None:
        _render_demo_placeholder()
        return

    # ── Process image
    col_img, col_results = st.columns([1, 1], gap="large")

    with col_img:
        st.markdown('<div class="section-header">🖼 Input Image</div>',
                    unsafe_allow_html=True)
        # Display raw upload
        pil_img = Image.open(uploaded_file)
        st.image(pil_img, caption="Uploaded X-ray", use_column_width=True)

    # ── Preprocess
    uploaded_file.seek(0)
    image_bytes = uploaded_file.read()

    try:
        preprocessed = preprocess_from_bytes(image_bytes)
    except Exception as e:
        st.error(f"❌ Image preprocessing failed: {e}")
        return

    if not model_loaded:
        st.warning("⚠ Upload a model checkpoint to run inference.")
        return

    # ── Inference + Grad-CAM
    with st.spinner("🧠 Running inference and generating Grad-CAM..."):
        start_t = time.time()
        heatmap, overlay, predicted_class, probabilities = gradcam.generate(
            preprocessed
        )
        elapsed = time.time() - start_t

    prediction = format_prediction(predicted_class, probabilities)

    # ── Results column
    with col_results:
        st.markdown('<div class="section-header">🔬 Diagnostic Result</div>',
                    unsafe_allow_html=True)

        grade_bg = {
            "Normal"  : "#0d3b26",
            "Mild"    : "#3b2e0d",
            "Moderate": "#3b1f0d",
            "Severe"  : "#3b0d0d"
        }.get(prediction["severity"], "#1a1d2e")

        st.markdown(f"""
        <div class="metric-card" style="background:{grade_bg}; border-color:{prediction['severity_color']}44">
            <p style="color:#aaa; margin-bottom:4px">Kellgren-Lawrence Grade</p>
            <h2 style="color:{prediction['severity_color']}; font-size:3rem">
                Grade {prediction['kl_grade']}
            </h2>
            <p style="color:#ddd; font-size:1rem">{prediction['grade_name']}</p>
            <p style="color:{prediction['severity_color']}; font-weight:bold">
                {prediction['severity']} OA
            </p>
        </div>
        """, unsafe_allow_html=True)

        # Confidence
        conf = prediction["confidence"]
        st.markdown(f"""
        <div style="margin: 12px 0">
            <p style="color:#aaa; margin:0 0 4px">Prediction Confidence</p>
            <div style="background:#1a1d2e; border-radius:8px; overflow:hidden; height:24px">
                <div style="
                    background:linear-gradient(90deg,{prediction['severity_color']},{prediction['severity_color']}88);
                    width:{conf*100:.1f}%;
                    height:100%;
                    display:flex;
                    align-items:center;
                    padding:0 8px;
                    color:white;
                    font-weight:bold;
                    font-size:0.85rem
                ">{conf:.1%}</div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        # Inference time
        st.caption(f"⚡ Inference time: {elapsed*1000:.1f} ms")

        st.markdown("---")

        # Probability breakdown
        st.markdown("**Class Probabilities**")
        bar_colors = ["#2ecc71", "#f1c40f", "#f39c12", "#e67e22", "#e74c3c"]
        for i, (name, color) in enumerate(zip(CLASS_NAMES.values(), bar_colors)):
            prob = float(probabilities[i])
            is_pred = (i == predicted_class)
            label_style = f"color:{color}; font-weight:{'bold' if is_pred else 'normal'}"
            st.markdown(
                f"<span style='{label_style}'>{'▶ ' if is_pred else '  '}KL {i}</span>",
                unsafe_allow_html=True
            )
            st.progress(prob)
            st.caption(f"{prob:.1%}")

    # ── Grad-CAM visualization
    st.markdown("---")
    st.markdown('<div class="section-header">🔥 Grad-CAM Visualization</div>',
                unsafe_allow_html=True)

    gradcam_fig = create_gradcam_figure(
        preprocessed, heatmap, overlay, predicted_class, probabilities
    )
    gradcam_bytes = fig_to_bytes(gradcam_fig)
    st.image(gradcam_bytes, use_column_width=True,
              caption="Grad-CAM: Highlighted regions influenced the model's prediction")

    # ── Clinical interpretation
    st.markdown("---")
    st.markdown('<div class="section-header">📋 Clinical Interpretation</div>',
                unsafe_allow_html=True)

    clinical = get_clinical_description(predicted_class)
    st.info(f"**Grade {predicted_class} – {CLASS_NAMES[predicted_class]}**\n\n{clinical}")

    # ── Report download
    st.markdown("---")
    st.markdown('<div class="section-header">📥 Export Report</div>',
                unsafe_allow_html=True)

    col_dl1, col_dl2 = st.columns(2)

    with col_dl1:
        # Grad-CAM image download
        st.download_button(
            label="⬇️ Download Grad-CAM Image (PNG)",
            data=gradcam_bytes,
            file_name=f"gradcam_KL{predicted_class}.png",
            mime="image/png",
            use_container_width=True
        )

    with col_dl2:
        # PDF report
        try:
            pdf_bytes = generate_pdf_report(
                original_image=preprocessed,
                gradcam_overlay=overlay,
                prediction=prediction
            )
            st.download_button(
                label="⬇️ Download Full PDF Report",
                data=pdf_bytes,
                file_name=f"knee_oa_report_KL{predicted_class}.pdf",
                mime="application/pdf",
                use_container_width=True
            )
        except ImportError:
            st.caption("⚠ Install `reportlab` to enable PDF export.")

    # ── Disclaimer
    st.markdown("""
    <div class="disclaimer">
    ⚠️ <b>DISCLAIMER:</b> This tool is intended for <b>research and educational purposes only</b>.
    Predictions are generated by an AI model and do <b>not</b> constitute a medical diagnosis.
    All findings must be reviewed and confirmed by a <b>qualified medical professional</b>.
    Do not use this output for clinical decision-making without expert review.
    </div>
    """, unsafe_allow_html=True)


# =============================================================================
# DEMO PLACEHOLDER
# =============================================================================

def _render_demo_placeholder():
    """Render an informational placeholder when no image is uploaded."""
    st.markdown("---")

    col1, col2, col3 = st.columns(3)

    stages = [
        ("🔬", "Preprocessing", "CLAHE contrast enhancement,\npadding & resizing to 224×224"),
        ("🧠", "Xception CNN", "36-layer depthwise separable\nconvolution backbone"),
        ("🔥", "Grad-CAM", "Visual explanation of\nprediction regions"),
    ]

    for col, (icon, title, desc) in zip([col1, col2, col3], stages):
        with col:
            st.markdown(f"""
            <div class="metric-card">
                <span style='font-size:2.5rem'>{icon}</span>
                <h4 style='color:#00d4ff; margin:8px 0 4px'>{title}</h4>
                <p style='color:#888; font-size:0.85rem; white-space:pre-line'>{desc}</p>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("---")

    # KL Grade reference table
    st.markdown('<div class="section-header">📊 Kellgren-Lawrence Grading Reference</div>',
                unsafe_allow_html=True)

    grade_colors = ["#2ecc71", "#f1c40f", "#f39c12", "#e67e22", "#e74c3c"]
    descriptions_short = [
        "No OA features – Normal joint",
        "Possible osteophyte – Doubtful OA",
        "Definite osteophyte, possible JSN",
        "Multiple osteophytes, JSN, sclerosis",
        "Large osteophytes, severe JSN, deformity"
    ]

    cols = st.columns(5)
    for i, (col, color, desc) in enumerate(zip(cols, grade_colors, descriptions_short)):
        with col:
            st.markdown(f"""
            <div class="metric-card" style="border-color:{color}55">
                <h2 style='color:{color}'>{i}</h2>
                <p style='color:{color}; font-weight:bold'>Grade {i}</p>
                <p style='font-size:0.75rem; color:#aaa'>{desc}</p>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("""
    <br>
    <div style='text-align:center; color:#555; font-size:0.85rem'>
        Upload a knee X-ray image above to begin classification ↑
    </div>
    """, unsafe_allow_html=True)


# =============================================================================

if __name__ == "__main__":
    main()
