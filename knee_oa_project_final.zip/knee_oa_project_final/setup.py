from setuptools import setup, find_packages

setup(
    name="knee_oa_xception",
    version="1.0.0",
    description=(
        "Xception-Based Deep Learning Framework for Knee Osteoarthritis "
        "Classification with Grad-CAM Interpretation"
    ),
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "tensorflow>=2.12.0",
        "opencv-python>=4.7.0",
        "Pillow>=9.5.0",
        "numpy>=1.23.0",
        "scikit-learn>=1.2.0",
        "matplotlib>=3.7.0",
        "seaborn>=0.12.0",
        "streamlit>=1.28.0",
        "reportlab>=4.0.0",
        "tqdm>=4.65.0",
        "pandas>=2.0.0",
    ],
    extras_require={
        "dicom": ["pydicom>=2.3.0"],
        "dev"  : ["pytest>=7.3.0", "jupyter>=1.0.0"],
    },
    entry_points={
        "console_scripts": [
            "koa-train=training.train:main",
            "koa-eval=training.evaluate:main",
            "koa-predict=scripts.predict:main",
        ]
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Medical Science Apps.",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
    ],
)
