# 🦴 Xception-Based Deep Learning Framework for Knee Osteoarthritis Classification with Grad-CAM Interpretation

---

## 📌 Overview

This project implements a complete deep learning pipeline for **automatic classification of knee osteoarthritis (OA) severity** from radiographic (X-ray) images.

The system classifies knee X-rays into five severity levels using the **Kellgren-Lawrence (KL) grading system** and provides **visual explanations** via **Grad-CAM (Gradient-weighted Class Activation Mapping)**, overlaying heatmaps on the original X-ray to highlight diagnostically relevant regions.

---

## 🏗 Pipeline Architecture

```
┌──────────────────────────────────────────────────────────────────────┐
│        XCEPTION-BASED KNEE OA CLASSIFICATION PIPELINE                │
├──────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  Stage 1 │ Clinical Data Acquisition & Preprocessing                  │
│          │  DICOM / PNG / JPG → CLAHE → Pad & Resize (224×224)       │
│          │  → Normalize [0,1]                                         │
│                                                                        │
│  Stage 2 │ Data Augmentation                                           │
│          │  Rotation ±15° · H-Flip · Translation · Zoom               │
│                                                                        │
│  Stage 3 │ Feature Extraction – Xception Backbone                     │
│          │  36 Conv Layers · Depthwise Separable Conv                 │
│          │  Residual Connections · ImageNet Pretrained                │
│                                                                        │
│  Stage 4 │ Global Feature Representation                               │
│          │  Global Average Pooling → 2048-dim vector                  │
│                                                                        │
│  Stage 5 │ Diagnostic Classification                                   │
│          │  Dense(512) → Dropout(0.5) → Dense(256) → Softmax(5)      │
│          │  → KL Grade 0 / 1 / 2 / 3 / 4                             │
│                                                                        │
│  Stage 6 │ Model Training & Optimization                               │
│          │  Adam · CategoricalCrossEntropy · EarlyStopping            │
│          │  Phase 1: Frozen backbone · Phase 2: Fine-tuning           │
│                                                                        │
│  Stage 7 │ Model Evaluation                                            │
│          │  Accuracy · Precision · Recall · F1 · ROC-AUC              │
│          │  Confusion Matrix · PR Curves                              │
│                                                                        │
│  Stage 8 │ Explainability – Grad-CAM                                  │
│          │  Gradients → Feature Maps → Heatmap → X-ray Overlay       │
│                                                                        │
│  Stage 9 │ Deployment – Streamlit Dashboard                           │
│          │  Upload → Predict → Visualize → Export PDF Report         │
└──────────────────────────────────────────────────────────────────────┘
```

---

## 📁 Project Structure

```
knee_oa_project/
│
├── app.py                          # Streamlit web dashboard (Stage 9)
├── config.py                       # Central configuration
├── requirements.txt
├── README.md
│
├── data/
│   ├── __init__.py
│   └── preprocessing.py            # Stages 1 & 2
│
├── model/
│   ├── __init__.py
│   ├── xception_model.py           # Stages 3, 4, 5
│   └── gradcam.py                  # Stage 8
│
├── training/
│   ├── __init__.py
│   ├── train.py                    # Stage 6
│   └── evaluate.py                 # Stage 7
│
├── utils/
│   ├── __init__.py
│   ├── helpers.py                  # Shared utilities
│   └── report_generator.py        # PDF report generation
│
├── scripts/
│   ├── prepare_dataset.py          # Dataset preparation
│   └── predict.py                  # CLI inference tool
│
├── data_raw/                       # Dataset (not included)
│   ├── train/
│   │   ├── 0/   ├── 1/   ├── 2/   ├── 3/   └── 4/
│   ├── val/
│   └── test/
│
├── checkpoints/                    # Saved model weights
├── reports/                        # Evaluation outputs & PDF reports
├── logs/                           # TensorBoard & CSV training logs
└── assets/                         # Static assets
```

---

## 🔢 Kellgren-Lawrence (KL) Grading System

| Grade | Condition        | Description |
|-------|-----------------|-------------|
| **0** | Normal          | No radiographic features of OA |
| **1** | Doubtful OA     | Possible osteophyte, equivocal findings |
| **2** | Mild OA         | Definite osteophyte, possible JSN |
| **3** | Moderate OA     | Multiple osteophytes, definite JSN, sclerosis |
| **4** | Severe OA       | Large osteophytes, marked JSN, bone deformity |

> **JSN** = Joint Space Narrowing

---

## 🚀 Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Prepare your dataset

Organize raw images into class folders (0–4):

```bash
python scripts/prepare_dataset.py \
    --src /path/to/raw/images \
    --dst data_raw \
    --train 0.70 \
    --val 0.15 \
    --test 0.15
```

### 3. Train the model

```bash
# Full two-phase training (recommended)
python training/train.py --phase both

# Phase 1 only (feature extraction)
python training/train.py --phase feature_extraction

# Phase 2 fine-tuning from existing checkpoint
python training/train.py --phase fine_tuning \
    --checkpoint checkpoints/xception_knee_oa_phase1_best.keras
```

### 4. Evaluate the model

```bash
python training/evaluate.py \
    --checkpoint checkpoints/xception_knee_oa_phase2_best.keras
```

### 5. Launch the web dashboard

```bash
streamlit run app.py
```

Navigate to `http://localhost:8501` in your browser.

### 6. CLI inference

```bash
# Single image
python scripts/predict.py \
    --image path/to/xray.jpg \
    --checkpoint checkpoints/xception_knee_oa_phase2_best.keras

# Batch inference
python scripts/predict.py \
    --dir path/to/images/ \
    --checkpoint checkpoints/xception_knee_oa_phase2_best.keras \
    --output_dir reports/predictions/
```

---

## 🧠 Model Architecture

### Xception Backbone
- **36 convolutional layers** using **depthwise separable convolutions**
- Separates spatial (depthwise) and channel-wise (pointwise) convolution
- **Residual connections** prevent vanishing gradients
- Pretrained on **ImageNet** (transfer learning)

### Classification Head
```
Xception (frozen / fine-tuned)
    → GlobalAveragePooling2D  [2048-dim]
    → BatchNorm → Dense(512, ReLU) → Dropout(0.5)
    → BatchNorm → Dense(256, ReLU) → Dropout(0.5)
    → Dense(5, Softmax)
```

---

## 🔥 Grad-CAM Explanation

Grad-CAM generates visual explanations by:
1. Computing **gradients** of the predicted class score w.r.t. feature maps
2. **Globally average pooling** the gradients over spatial dimensions
3. **Weighting** each feature map by its pooled gradient
4. Summing weighted maps and applying **ReLU**
5. **Upsampling** the activation map to input resolution
6. **Overlaying** as a color heatmap on the original X-ray

This allows clinicians to visually verify that the model focuses on anatomically relevant regions (joint space, osteophytes, subchondral bone).

---

## 📊 Evaluation Metrics

The evaluation module (`training/evaluate.py`) computes:

- **Accuracy** – overall classification accuracy
- **Precision** – per-class positive predictive value
- **Recall** (Sensitivity) – per-class true positive rate
- **F1-Score** – harmonic mean of precision and recall
- **ROC-AUC** – area under the ROC curve (one-vs-rest)
- **Confusion Matrix** – raw and normalized
- **Precision-Recall Curves** – per class
- **Training History Plots** – accuracy and loss curves

---

## ⚙️ Configuration

All hyperparameters and paths are centralized in `config.py`:

```python
IMAGE_SIZE      = (224, 224)     # Xception input resolution
BATCH_SIZE      = 32
EPOCHS          = 50
LEARNING_RATE   = 1e-4
DROPOUT_RATE    = 0.5
NUM_CLASSES     = 5              # KL grades 0-4
CLAHE_CLIP      = 2.0            # CLAHE contrast enhancement
GRADCAM_LAYER   = "block14_sepconv2_act"
```

---

## 📄 Report Export

The Streamlit dashboard and PDF report generator produce:
- Uploaded X-ray image
- Predicted KL grade and confidence score
- Class probability breakdown
- Grad-CAM heatmap visualization
- Clinical interpretation
- Unique report ID and timestamp

---

## 🗂 Recommended Datasets

| Dataset | Source | Notes |
|---------|--------|-------|
| OAI (Osteoarthritis Initiative) | [NCBI](https://nda.nih.gov/oai/) | Gold standard, 4,796 patients |
| MOST | [NCBI](https://most.ucsf.edu/) | Multi-center OA study |
| Kaggle Knee OA | [Kaggle](https://www.kaggle.com/datasets/shashwatwork/knee-osteoarthritis-dataset-with-severity) | 8,260 X-ray images |

---

## 📋 Requirements Summary

| Package | Purpose |
|---------|---------|
| `tensorflow >= 2.12` | Deep learning framework |
| `opencv-python`      | CLAHE, image processing |
| `streamlit`          | Web dashboard |
| `reportlab`          | PDF report generation |
| `scikit-learn`       | Evaluation metrics |
| `matplotlib / seaborn` | Plotting |
| `pydicom` (optional) | DICOM file support |

---

## ⚠️ Disclaimer

> This system is developed for **research and educational purposes only**.  
> It does **not** constitute a clinical diagnosis.  
> All model outputs must be reviewed and validated by a **qualified radiologist or orthopaedic clinician** before any clinical use.

---

## 👨‍💻 System Information

| Item | Details |
|------|---------|
| Architecture | Xception (Extreme Inception) |
| Input Size | 224 × 224 × 3 |
| Output | 5-class Softmax (KL 0–4) |
| Explainability | Grad-CAM |
| Preprocessing | CLAHE + Pad & Resize |
| Optimizer | Adam |
| Loss | Categorical Cross-Entropy |
| Framework | TensorFlow / Keras |
| Interface | Streamlit |
